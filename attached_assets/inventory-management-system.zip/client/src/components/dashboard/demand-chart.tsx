import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { MoreVertical } from "lucide-react";
import { useBatchDemandForecasts } from "@/hooks/use-inventory";

const DemandChart = () => {
  const { data: forecasts, isLoading, error } = useBatchDemandForecasts();
  const [chartData, setChartData] = useState<any[]>([]);
  
  useEffect(() => {
    if (forecasts) {
      const aggregatedData = calculateAggregatedData(forecasts);
      setChartData(aggregatedData);
    }
  }, [forecasts]);
  
  const calculateAggregatedData = (forecasts: any) => {
    // Initialize days of week
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "Mon (f)", "Tue (f)"];
    const data = days.map(day => ({ name: day, value: 0 }));
    
    // Dummy historical data (last 7 days)
    data[0].value = 124; // Mon
    data[1].value = 148; // Tue
    data[2].value = 80;  // Wed
    data[3].value = 105; // Thu
    data[4].value = 162; // Fri
    data[5].value = 175; // Sat
    data[6].value = 133; // Sun
    
    // If we have forecast data, use it for the forecast days
    if (forecasts && forecasts.length > 0) {
      // Calculate average forecast for each day
      let mondayForecast = 0;
      let tuesdayForecast = 0;
      
      forecasts.forEach((forecast: any) => {
        if (forecast.forecast && forecast.forecast.forecast) {
          mondayForecast += forecast.forecast.forecast[0] || 0;
          tuesdayForecast += forecast.forecast.forecast[1] || 0;
        }
      });
      
      const count = forecasts.length;
      data[7].value = Math.round(mondayForecast / count) || 139; // Monday forecast
      data[8].value = Math.round(tuesdayForecast / count) || 152; // Tuesday forecast
    } else {
      // Use dummy forecast data if no real data
      data[7].value = 139; // Monday forecast
      data[8].value = 152; // Tuesday forecast
    }
    
    return data;
  };
  
  if (isLoading) {
    return (
      <Card className="lg:col-span-2">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-base font-medium">Weekly Demand Forecast</CardTitle>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
                  <MoreVertical className="h-5 w-5 text-gray-500" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Export Data</DropdownMenuItem>
                <DropdownMenuItem>Refresh</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[250px] flex items-center justify-center">
            <div className="animate-pulse rounded-md bg-gray-200 dark:bg-gray-800 w-full h-full" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error) {
    return (
      <Card className="lg:col-span-2">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Weekly Demand Forecast</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[250px] flex items-center justify-center text-red-500">
            Error loading forecast data
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="lg:col-span-2">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-base font-medium">Weekly Demand Forecast</CardTitle>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
                <MoreVertical className="h-5 w-5 text-gray-500" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Export Data</DropdownMenuItem>
              <DropdownMenuItem>Refresh</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[250px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 12 }} 
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 12 }} 
                tickLine={false}
                axisLine={false}
              />
              <Tooltip 
                formatter={(value) => [`${value} units`, 'Demand']}
                labelFormatter={(label) => `Day: ${label}`}
              />
              <Line 
                type="monotone" 
                dataKey="value" 
                name="Demand"
                stroke="#3f51b5" 
                activeDot={{ r: 8 }} 
                strokeWidth={2}
                dot={{ r: 3 }}
                isAnimationActive={true}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 flex items-center justify-between text-sm">
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 bg-primary rounded-sm mr-2"></span>
            <span className="text-gray-500 dark:text-gray-400">Actual</span>
          </div>
          <div className="flex items-center">
            <span className="inline-block w-3 h-3 bg-primary bg-opacity-40 rounded-sm mr-2"></span>
            <span className="text-gray-500 dark:text-gray-400">Forecast</span>
          </div>
          <div className="text-right">
            <span className="text-xs text-gray-500 dark:text-gray-400">
              Confidence: <span className="text-primary font-medium">85%</span>
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DemandChart;

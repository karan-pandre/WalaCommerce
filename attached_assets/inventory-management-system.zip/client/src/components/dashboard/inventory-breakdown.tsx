import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { useDashboardStats } from "@/hooks/use-inventory";
import { getRandomColor } from "@/lib/utils";

const InventoryBreakdown = () => {
  const { data: stats, isLoading, error } = useDashboardStats();
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-base font-medium">Inventory Breakdown</CardTitle>
            <button className="text-primary text-sm">View All</button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center mb-6">
            <div className="animate-pulse rounded-full bg-gray-200 dark:bg-gray-800 w-[150px] h-[150px]" />
          </div>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex justify-between">
                <div className="w-2/3 h-4 bg-gray-200 dark:bg-gray-800 rounded animate-pulse"></div>
                <div className="w-1/5 h-4 bg-gray-200 dark:bg-gray-800 rounded animate-pulse"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Inventory Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[250px] flex items-center justify-center text-red-500">
            Error loading inventory breakdown
          </div>
        </CardContent>
      </Card>
    );
  }
  
  let chartData = [
    { name: "Electronics", value: 55 },
    { name: "Clothing", value: 15 },
    { name: "Home Goods", value: 15 },
    { name: "Other", value: 15 }
  ];
  
  // If we have actual data, use it
  if (stats && stats.categoryBreakdown) {
    chartData = stats.categoryBreakdown.map(item => ({
      name: item.category,
      value: item.percentage
    }));
  }
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-base font-medium">Inventory Breakdown</CardTitle>
          <button className="text-primary text-sm">View All</button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex justify-center mb-6 h-[150px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={60}
                paddingAngle={2}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getRandomColor(index)} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => [`${value}%`, 'Percentage']} 
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        
        <div className="space-y-3">
          {chartData.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center">
                <span 
                  className="inline-block w-3 h-3 rounded-sm mr-2" 
                  style={{ backgroundColor: getRandomColor(index) }}
                ></span>
                <span className="text-sm dark:text-gray-300">{item.name}</span>
              </div>
              <span className="font-medium dark:text-gray-200">{item.value}%</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default InventoryBreakdown;

import { ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    type: "increase" | "decrease";
    label?: string;
  };
  icon: ReactNode;
  iconBgClass?: string;
}

const StatsCard = ({ 
  title, 
  value, 
  change, 
  icon, 
  iconBgClass = "bg-primary/10" 
}: StatsCardProps) => {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-gray-500 dark:text-gray-400 text-sm font-medium">{title}</h3>
          <div className={cn("p-2 rounded-full", iconBgClass)}>
            {icon}
          </div>
        </div>
        <div className="flex items-end">
          <span className="text-2xl font-semibold dark:text-white">{value}</span>
          {change && (
            <span 
              className={cn(
                "ml-2 text-xs", 
                change.type === "increase" ? "text-green-500" : "text-red-500"
              )}
            >
              {change.type === "increase" ? "+" : "-"}
              {Math.abs(change.value).toFixed(1)}% 
              <span className="text-gray-500 dark:text-gray-400">
                {change.label || "from last month"}
              </span>
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StatsCard;

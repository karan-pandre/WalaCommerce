import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  ArrowUp, 
  ArrowDown, 
  AlertTriangle 
} from "lucide-react";
import { useInventoryActivities } from "@/hooks/use-inventory";
import { formatDate, getStatusColor } from "@/lib/utils";

const ActivityTable = () => {
  const { data: activities, isLoading, error } = useInventoryActivities(5);
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle className="text-base font-medium">Recent Inventory Activities</CardTitle>
            <button className="text-primary text-sm">View All</button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 dark:bg-gray-800 rounded w-full"></div>
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-14 bg-gray-200 dark:bg-gray-800 rounded w-full"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (error) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Recent Inventory Activities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4 text-red-500">
            Error loading inventory activities
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-base font-medium">Recent Inventory Activities</CardTitle>
          <button className="text-primary text-sm">View All</button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-b text-left text-sm font-medium text-gray-500 dark:text-gray-400">
                <TableHead className="py-3 pr-4">Activity</TableHead>
                <TableHead className="py-3 pr-4">Product ID</TableHead>
                <TableHead className="py-3 pr-4">Product Name</TableHead>
                <TableHead className="py-3 pr-4">Quantity</TableHead>
                <TableHead className="py-3 pr-4">Date</TableHead>
                <TableHead className="py-3">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {activities && activities.length > 0 ? (
                activities.map((activity) => (
                  <TableRow 
                    key={activity.id} 
                    className="border-b hover:bg-gray-50 dark:hover:bg-gray-900"
                  >
                    <TableCell className="py-3 pr-4">
                      <div className="flex items-center">
                        <div className={`${activity.quantity > 0 ? 'bg-blue-100 dark:bg-blue-900' : 'bg-red-100 dark:bg-red-900'} p-2 rounded-full mr-2`}>
                          {activity.quantity > 0 ? (
                            <ArrowUp className="h-4 w-4 text-blue-500 dark:text-blue-300" />
                          ) : activity.activityType === 'adjustment' ? (
                            <ArrowDown className="h-4 w-4 text-red-500 dark:text-red-300" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-yellow-500 dark:text-yellow-300" />
                          )}
                        </div>
                        <span className="dark:text-gray-300">
                          {activity.activityType === 'received' 
                            ? 'Stock Received'
                            : activity.activityType === 'adjustment'
                            ? 'Stock Adjustment'
                            : 'Low Stock Alert'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="py-3 pr-4 dark:text-gray-300">PRD-{activity.productId}</TableCell>
                    <TableCell className="py-3 pr-4 dark:text-gray-300">{activity.productName}</TableCell>
                    <TableCell className="py-3 pr-4 dark:text-gray-300">
                      {activity.quantity > 0 ? `+${activity.quantity}` : activity.quantity} units
                    </TableCell>
                    <TableCell className="py-3 pr-4 dark:text-gray-300">{formatDate(activity.lastUpdated)}</TableCell>
                    <TableCell className="py-3">
                      <span className={`text-xs py-1 px-2 rounded-full ${
                        activity.activityType === 'received' 
                        ? getStatusColor('completed')
                        : activity.activityType === 'adjustment'
                        ? getStatusColor('verified')
                        : getStatusColor('pending')
                      }`}>
                        {activity.activityType === 'received' 
                          ? 'Completed'
                          : activity.activityType === 'adjustment'
                          ? 'Verified'
                          : 'Pending'}
                      </span>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4 text-gray-500 dark:text-gray-400">
                    No recent inventory activities found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default ActivityTable;

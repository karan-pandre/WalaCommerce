import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useSyncHistory } from "@/hooks/use-settings";
import { formatDateTime, getStatusColor } from "@/lib/utils";
import { Loader2, AlertTriangle } from "lucide-react";

const SyncHistory = () => {
  const { data: history, isLoading, error } = useSyncHistory();
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Sync History</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Review previous synchronization activities
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="flex justify-center items-center py-8 text-red-500">
            <AlertTriangle className="h-8 w-8 mr-2" />
            <p>Error loading sync history</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sync ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Records</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {history && history.length > 0 ? (
                  history.map((item) => {
                    const durationFormatted = item.durationSeconds >= 60
                      ? `${Math.floor(item.durationSeconds / 60)}m ${item.durationSeconds % 60}s`
                      : `${item.durationSeconds}s`;
                      
                    return (
                      <TableRow key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-900">
                        <TableCell className="dark:text-gray-300">SYNC-{item.id.toString().padStart(5, '0')}</TableCell>
                        <TableCell className="dark:text-gray-300">{formatDateTime(item.createdAt)}</TableCell>
                        <TableCell className="dark:text-gray-300">{item.syncType.charAt(0).toUpperCase() + item.syncType.slice(1)}</TableCell>
                        <TableCell className="dark:text-gray-300">{item.recordsProcessed} products</TableCell>
                        <TableCell className="dark:text-gray-300">{durationFormatted}</TableCell>
                        <TableCell>
                          <span className={`text-xs py-1 px-2 rounded-full ${getStatusColor(item.status)}`}>
                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button variant="link" className="p-0 h-auto text-primary">
                            View Log
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-gray-500 dark:text-gray-400">
                      No synchronization history found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
        
        {history && history.length > 0 && (
          <div className="mt-4 flex justify-between">
            <Button variant="ghost" className="text-primary">Export History</Button>
            <div className="flex space-x-2">
              <Button variant="outline">Previous</Button>
              <Button variant="default">1</Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">Next</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SyncHistory;

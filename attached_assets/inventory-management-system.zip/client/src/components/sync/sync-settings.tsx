import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useSettingsByCategory, useUpdateSetting } from "@/hooks/use-settings";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { useCreateSyncHistoryEntry } from "@/hooks/use-settings";

const SyncSettings = () => {
  const [formValues, setFormValues] = useState({
    autoSync: true,
    realTimeUpdates: false,
    syncFrequency: "daily",
    syncTime: "01:00",
    productInfo: true,
    inventoryLevels: true,
    pricingInfo: true,
    customerData: false,
    syncFailureAction: "retry_1h",
    notificationRecipients: "admin@example.com"
  });
  
  const { data: settings, isLoading } = useSettingsByCategory("sync");
  const updateSetting = useUpdateSetting();
  const createSyncHistory = useCreateSyncHistoryEntry();
  const { toast } = useToast();
  
  // Load settings when data is available
  useEffect(() => {
    if (settings) {
      const newValues = { ...formValues };
      
      settings.forEach(setting => {
        switch (setting.key) {
          case "auto_sync":
            newValues.autoSync = setting.value === "true";
            break;
          case "real_time_updates":
            newValues.realTimeUpdates = setting.value === "true";
            break;
          case "sync_frequency":
            newValues.syncFrequency = setting.value;
            break;
          case "sync_time":
            newValues.syncTime = setting.value;
            break;
          case "sync_product_info":
            newValues.productInfo = setting.value === "true";
            break;
          case "sync_inventory":
            newValues.inventoryLevels = setting.value === "true";
            break;
          case "sync_pricing":
            newValues.pricingInfo = setting.value === "true";
            break;
          case "sync_customer_data":
            newValues.customerData = setting.value === "true";
            break;
          case "sync_failure_action":
            newValues.syncFailureAction = setting.value;
            break;
          case "sync_notification_emails":
            newValues.notificationRecipients = setting.value;
            break;
        }
      });
      
      setFormValues(newValues);
    }
  }, [settings]);
  
  const handleSaveChanges = async () => {
    try {
      // Update all settings
      await updateSetting.mutateAsync({ key: "auto_sync", value: formValues.autoSync.toString() });
      await updateSetting.mutateAsync({ key: "real_time_updates", value: formValues.realTimeUpdates.toString() });
      await updateSetting.mutateAsync({ key: "sync_frequency", value: formValues.syncFrequency });
      await updateSetting.mutateAsync({ key: "sync_time", value: formValues.syncTime });
      await updateSetting.mutateAsync({ key: "sync_product_info", value: formValues.productInfo.toString() });
      await updateSetting.mutateAsync({ key: "sync_inventory", value: formValues.inventoryLevels.toString() });
      await updateSetting.mutateAsync({ key: "sync_pricing", value: formValues.pricingInfo.toString() });
      await updateSetting.mutateAsync({ key: "sync_customer_data", value: formValues.customerData.toString() });
      await updateSetting.mutateAsync({ key: "sync_failure_action", value: formValues.syncFailureAction });
      await updateSetting.mutateAsync({ key: "sync_notification_emails", value: formValues.notificationRecipients });
      
      toast({
        title: "Settings saved",
        description: "Synchronization settings have been updated successfully."
      });
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your synchronization settings.",
        variant: "destructive"
      });
    }
  };
  
  const handleManualSync = async () => {
    try {
      // Simulate a sync process
      toast({
        title: "Sync started",
        description: "Manual synchronization is in progress..."
      });
      
      // Add entry to sync history
      await createSyncHistory.mutateAsync({
        syncType: "manual",
        recordsProcessed: Math.floor(Math.random() * 10) + 1, // Random number for demo
        durationSeconds: Math.floor(Math.random() * 60) + 5, // Random duration
        status: "completed",
        errorMessage: ""
      });
      
      toast({
        title: "Sync completed",
        description: "Manual synchronization completed successfully."
      });
    } catch (error) {
      toast({
        title: "Sync failed",
        description: "There was a problem during synchronization.",
        variant: "destructive"
      });
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="border-b">
          <CardTitle>Synchronization Settings</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center items-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Synchronization Settings</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Configure how inventory data is synchronized across systems
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="mb-6">
          <h4 className="font-medium mb-2 dark:text-white">General Settings</h4>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 border rounded-md dark:border-gray-700">
              <div>
                <p className="font-medium dark:text-white">Automatic Synchronization</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Enable or disable scheduled automatic syncs</p>
              </div>
              <Switch 
                checked={formValues.autoSync} 
                onCheckedChange={(checked) => setFormValues({...formValues, autoSync: checked})}
              />
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-md dark:border-gray-700">
              <div>
                <p className="font-medium dark:text-white">Real-time Updates</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Push updates immediately when inventory changes</p>
              </div>
              <Switch 
                checked={formValues.realTimeUpdates} 
                onCheckedChange={(checked) => setFormValues({...formValues, realTimeUpdates: checked})}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Sync Frequency</Label>
                <Select 
                  value={formValues.syncFrequency} 
                  onValueChange={(value) => setFormValues({...formValues, syncFrequency: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Daily Sync Time</Label>
                <Input 
                  type="time" 
                  value={formValues.syncTime} 
                  onChange={(e) => setFormValues({...formValues, syncTime: e.target.value})}
                />
              </div>
            </div>
          </div>
        </div>
        
        <div className="mb-6">
          <h4 className="font-medium mb-2 dark:text-white">Data Synchronization</h4>
          <div className="space-y-4">
            <div className="flex items-center p-3 border rounded-md dark:border-gray-700">
              <Checkbox 
                id="productInfo" 
                checked={formValues.productInfo} 
                onCheckedChange={(checked) => setFormValues({...formValues, productInfo: checked as boolean})}
                className="mr-3"
              />
              <div>
                <Label htmlFor="productInfo" className="font-medium dark:text-white">Product Information</Label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Names, descriptions, categories, etc.</p>
              </div>
            </div>
            
            <div className="flex items-center p-3 border rounded-md dark:border-gray-700">
              <Checkbox 
                id="inventoryLevels" 
                checked={formValues.inventoryLevels} 
                onCheckedChange={(checked) => setFormValues({...formValues, inventoryLevels: checked as boolean})}
                className="mr-3"
              />
              <div>
                <Label htmlFor="inventoryLevels" className="font-medium dark:text-white">Inventory Levels</Label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Stock quantities, locations</p>
              </div>
            </div>
            
            <div className="flex items-center p-3 border rounded-md dark:border-gray-700">
              <Checkbox 
                id="pricingInfo" 
                checked={formValues.pricingInfo} 
                onCheckedChange={(checked) => setFormValues({...formValues, pricingInfo: checked as boolean})}
                className="mr-3"
              />
              <div>
                <Label htmlFor="pricingInfo" className="font-medium dark:text-white">Pricing Information</Label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Cost, retail price, discounts</p>
              </div>
            </div>
            
            <div className="flex items-center p-3 border rounded-md dark:border-gray-700">
              <Checkbox 
                id="customerData" 
                checked={formValues.customerData} 
                onCheckedChange={(checked) => setFormValues({...formValues, customerData: checked as boolean})}
                className="mr-3"
              />
              <div>
                <Label htmlFor="customerData" className="font-medium dark:text-white">Customer Data</Label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Purchase history, preferences</p>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h4 className="font-medium mb-2 dark:text-white">Error Handling</h4>
          <div className="space-y-4">
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">On Sync Failure</Label>
              <Select 
                value={formValues.syncFailureAction} 
                onValueChange={(value) => setFormValues({...formValues, syncFailureAction: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select action" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="retry_immediate">Retry immediately</SelectItem>
                  <SelectItem value="retry_1h">Retry after 1 hour</SelectItem>
                  <SelectItem value="skip">Skip until next scheduled sync</SelectItem>
                  <SelectItem value="notify_only">Notify administrator only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Notification Recipients</Label>
              <Input 
                type="text" 
                value={formValues.notificationRecipients}
                placeholder="Email addresses (comma separated)"
                onChange={(e) => setFormValues({...formValues, notificationRecipients: e.target.value})}
              />
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex flex-wrap justify-between gap-3">
          <Button 
            variant="outline" 
            onClick={handleManualSync}
            disabled={createSyncHistory.isPending}
          >
            {createSyncHistory.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Sync Now
          </Button>
          
          <div className="space-x-3">
            <Button variant="outline">
              Cancel
            </Button>
            <Button 
              className="bg-primary text-white"
              onClick={handleSaveChanges}
              disabled={updateSetting.isPending}
            >
              {updateSetting.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SyncSettings;

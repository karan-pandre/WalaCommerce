import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

const SystemInfo = () => {
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>System Information</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Current system status
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="space-y-4">
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Version</p>
            <p className="font-medium dark:text-white">v2.5.3</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Last Update</p>
            <p className="font-medium dark:text-white">July 10, 2023</p>
          </div>
          
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Database Status</p>
            <div className="flex items-center">
              <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              <p className="font-medium text-green-500">Connected</p>
            </div>
          </div>
          
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">API Status</p>
            <div className="flex items-center">
              <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              <p className="font-medium text-green-500">Operational</p>
            </div>
          </div>
          
          <div className="pt-4 border-t dark:border-gray-700">
            <div className="flex justify-between mb-2">
              <p className="text-sm font-medium dark:text-white">Database Usage</p>
              <p className="text-sm dark:text-gray-300">62%</p>
            </div>
            <Progress value={62} className="h-2" />
          </div>
          
          <div className="pt-2">
            <div className="flex justify-between mb-2">
              <p className="text-sm font-medium dark:text-white">Storage Usage</p>
              <p className="text-sm dark:text-gray-300">45%</p>
            </div>
            <Progress value={45} className="h-2" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SystemInfo;

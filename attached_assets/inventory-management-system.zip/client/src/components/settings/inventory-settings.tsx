import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useSettingsByCategory, useUpdateSetting } from "@/hooks/use-settings";
import { useToast } from "@/hooks/use-toast";

const InventorySettings = () => {
  const [formValues, setFormValues] = useState({
    leadTimeDays: "5",
    safetyStockPercentage: "15",
    orderCost: "20",
    holdingCostPercentage: "25",
    autoCalculateReorderPoints: true
  });
  
  const { data: settings, isLoading } = useSettingsByCategory("inventory");
  const updateSetting = useUpdateSetting();
  const { toast } = useToast();
  
  // Load settings when data is available
  useEffect(() => {
    if (settings) {
      const newValues = { ...formValues };
      
      settings.forEach(setting => {
        switch (setting.key) {
          case "lead_time_days":
            newValues.leadTimeDays = setting.value || "5";
            break;
          case "safety_stock_percentage":
            newValues.safetyStockPercentage = setting.value || "15";
            break;
          case "order_cost":
            newValues.orderCost = setting.value || "20";
            break;
          case "holding_cost_percentage":
            newValues.holdingCostPercentage = setting.value || "25";
            break;
          case "auto_calculate_reorder":
            newValues.autoCalculateReorderPoints = setting.value === "true";
            break;
        }
      });
      
      setFormValues(newValues);
    }
  }, [settings]);
  
  const handleSaveChanges = async () => {
    try {
      // Validate numeric inputs
      const leadTime = parseInt(formValues.leadTimeDays);
      const safetyStock = parseInt(formValues.safetyStockPercentage);
      const orderCost = parseFloat(formValues.orderCost);
      const holdingCost = parseFloat(formValues.holdingCostPercentage);
      
      if (isNaN(leadTime) || leadTime <= 0) {
        toast({
          title: "Invalid lead time",
          description: "Lead time must be a positive number",
          variant: "destructive"
        });
        return;
      }
      
      if (isNaN(safetyStock) || safetyStock < 0 || safetyStock > 100) {
        toast({
          title: "Invalid safety stock percentage",
          description: "Safety stock percentage must be between 0 and 100",
          variant: "destructive"
        });
        return;
      }
      
      if (isNaN(orderCost) || orderCost < 0) {
        toast({
          title: "Invalid order cost",
          description: "Order cost must be a non-negative number",
          variant: "destructive"
        });
        return;
      }
      
      if (isNaN(holdingCost) || holdingCost < 0 || holdingCost > 100) {
        toast({
          title: "Invalid holding cost percentage",
          description: "Holding cost percentage must be between 0 and 100",
          variant: "destructive"
        });
        return;
      }
      
      // Update all settings
      await updateSetting.mutateAsync({ key: "lead_time_days", value: formValues.leadTimeDays });
      await updateSetting.mutateAsync({ key: "safety_stock_percentage", value: formValues.safetyStockPercentage });
      await updateSetting.mutateAsync({ key: "order_cost", value: formValues.orderCost });
      await updateSetting.mutateAsync({ key: "holding_cost_percentage", value: formValues.holdingCostPercentage });
      await updateSetting.mutateAsync({ key: "auto_calculate_reorder", value: formValues.autoCalculateReorderPoints.toString() });
      
      toast({
        title: "Settings saved",
        description: "Inventory settings have been updated successfully."
      });
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your inventory settings.",
        variant: "destructive"
      });
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="border-b">
          <CardTitle>Inventory Settings</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center items-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Inventory Settings</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Configure inventory calculation parameters
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="grid grid-cols-1 gap-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Default Lead Time (days)</Label>
              <Input
                type="number"
                min="1"
                value={formValues.leadTimeDays}
                onChange={(e) => setFormValues({...formValues, leadTimeDays: e.target.value})}
              />
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Default Safety Stock Percentage</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={formValues.safetyStockPercentage}
                onChange={(e) => setFormValues({...formValues, safetyStockPercentage: e.target.value})}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Percentage of average demand</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Order Cost ($)</Label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={formValues.orderCost}
                onChange={(e) => setFormValues({...formValues, orderCost: e.target.value})}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Fixed cost per order</p>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Holding Cost Percentage</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={formValues.holdingCostPercentage}
                onChange={(e) => setFormValues({...formValues, holdingCostPercentage: e.target.value})}
              />
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Annual percentage of item value</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-3 border rounded-md dark:border-gray-700">
            <div>
              <p className="font-medium dark:text-white">Auto-calculate Reorder Points</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Automatically set reorder points based on demand</p>
            </div>
            <Switch 
              checked={formValues.autoCalculateReorderPoints} 
              onCheckedChange={(checked) => setFormValues({...formValues, autoCalculateReorderPoints: checked})}
            />
          </div>
          
          <div className="flex justify-end">
            <Button 
              className="bg-primary text-white"
              onClick={handleSaveChanges}
              disabled={updateSetting.isPending}
            >
              {updateSetting.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InventorySettings;

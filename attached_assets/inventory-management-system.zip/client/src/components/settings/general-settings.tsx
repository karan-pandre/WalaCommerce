import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useSettingsByCategory, useUpdateSetting } from "@/hooks/use-settings";
import { useAppContext } from "@/contexts/app-context";

const GeneralSettings = () => {
  const [formValues, setFormValues] = useState({
    companyName: "InventoryPro Inc.",
    currency: "USD",
    dateFormat: "MM/DD/YYYY",
    timeZone: "UTC-08:00",
    language: "English",
    darkMode: false
  });
  
  const { data: settings, isLoading } = useSettingsByCategory("general");
  const updateSetting = useUpdateSetting();
  const { toggleDarkMode, isDarkMode } = useAppContext();
  
  // Load settings when data is available
  useEffect(() => {
    if (settings) {
      const newValues = { ...formValues };
      
      settings.forEach(setting => {
        switch (setting.key) {
          case "company_name":
            newValues.companyName = setting.value || "InventoryPro Inc.";
            break;
          case "currency":
            newValues.currency = setting.value || "USD";
            break;
          case "date_format":
            newValues.dateFormat = setting.value || "MM/DD/YYYY";
            break;
          case "time_zone":
            newValues.timeZone = setting.value || "UTC-08:00";
            break;
          case "language":
            newValues.language = setting.value || "English";
            break;
          case "dark_mode":
            newValues.darkMode = setting.value === "true";
            break;
        }
      });
      
      setFormValues(newValues);
    }
  }, [settings]);
  
  // Update dark mode in context when form value changes
  useEffect(() => {
    if (formValues.darkMode !== isDarkMode) {
      setFormValues(prev => ({ ...prev, darkMode: isDarkMode }));
    }
  }, [isDarkMode]);
  
  const handleSaveChanges = async () => {
    try {
      // Update all settings
      await updateSetting.mutateAsync({ key: "company_name", value: formValues.companyName });
      await updateSetting.mutateAsync({ key: "currency", value: formValues.currency });
      await updateSetting.mutateAsync({ key: "date_format", value: formValues.dateFormat });
      await updateSetting.mutateAsync({ key: "time_zone", value: formValues.timeZone });
      await updateSetting.mutateAsync({ key: "language", value: formValues.language });
      
      // Dark mode is handled by the context
      if (formValues.darkMode !== isDarkMode) {
        toggleDarkMode();
      }
    } catch (error) {
      console.error("Error saving settings:", error);
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="border-b">
          <CardTitle>General Settings</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center items-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>General Settings</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Configure basic system behavior
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="grid grid-cols-1 gap-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Company Name</Label>
              <Input
                value={formValues.companyName}
                onChange={(e) => setFormValues({...formValues, companyName: e.target.value})}
              />
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Currency</Label>
              <Select
                value={formValues.currency}
                onValueChange={(value) => setFormValues({...formValues, currency: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                  <SelectItem value="JPY">JPY (¥)</SelectItem>
                  <SelectItem value="CAD">CAD (C$)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Date Format</Label>
              <Select
                value={formValues.dateFormat}
                onValueChange={(value) => setFormValues({...formValues, dateFormat: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select date format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                  <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                  <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Time Zone</Label>
              <Select
                value={formValues.timeZone}
                onValueChange={(value) => setFormValues({...formValues, timeZone: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select time zone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UTC-08:00">(UTC-08:00) Pacific Time</SelectItem>
                  <SelectItem value="UTC-05:00">(UTC-05:00) Eastern Time</SelectItem>
                  <SelectItem value="UTC+00:00">(UTC+00:00) UTC</SelectItem>
                  <SelectItem value="UTC+01:00">(UTC+01:00) Central European Time</SelectItem>
                  <SelectItem value="UTC+08:00">(UTC+08:00) China Standard Time</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Default Language</Label>
            <Select
              value={formValues.language}
              onValueChange={(value) => setFormValues({...formValues, language: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Spanish">Spanish</SelectItem>
                <SelectItem value="French">French</SelectItem>
                <SelectItem value="German">German</SelectItem>
                <SelectItem value="Chinese">Chinese</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center justify-between p-3 border rounded-md dark:border-gray-700">
            <div>
              <p className="font-medium dark:text-white">Enable Dark Mode</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Switch between light and dark theme</p>
            </div>
            <Switch 
              checked={formValues.darkMode} 
              onCheckedChange={(checked) => setFormValues({...formValues, darkMode: checked})}
            />
          </div>
          
          <div className="flex justify-end">
            <Button 
              className="bg-primary text-white"
              onClick={handleSaveChanges}
              disabled={updateSetting.isPending}
            >
              {updateSetting.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GeneralSettings;

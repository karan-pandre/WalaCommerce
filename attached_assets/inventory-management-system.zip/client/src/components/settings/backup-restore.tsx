import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Loader2, Upload, Download } from "lucide-react";
import { useSettingsByCategory, useUpdateSetting } from "@/hooks/use-settings";
import { useToast } from "@/hooks/use-toast";
import { useCreateSyncHistoryEntry } from "@/hooks/use-settings";

const BackupRestore = () => {
  const [formValues, setFormValues] = useState({
    backupFrequency: "daily",
    backupRetention: "30",
    cloudBackup: true
  });
  
  const [backupInProgress, setBackupInProgress] = useState(false);
  const [restoreInProgress, setRestoreInProgress] = useState(false);
  
  const { data: settings, isLoading } = useSettingsByCategory("backup");
  const updateSetting = useUpdateSetting();
  const createSyncHistory = useCreateSyncHistoryEntry();
  const { toast } = useToast();
  
  // Load settings when data is available
  useEffect(() => {
    if (settings) {
      const newValues = { ...formValues };
      
      settings.forEach(setting => {
        switch (setting.key) {
          case "backup_frequency":
            newValues.backupFrequency = setting.value || "daily";
            break;
          case "backup_retention":
            newValues.backupRetention = setting.value || "30";
            break;
          case "cloud_backup":
            newValues.cloudBackup = setting.value === "true";
            break;
        }
      });
      
      setFormValues(newValues);
    }
  }, [settings]);
  
  const handleSaveChanges = async () => {
    try {
      // Update all settings
      await updateSetting.mutateAsync({ key: "backup_frequency", value: formValues.backupFrequency });
      await updateSetting.mutateAsync({ key: "backup_retention", value: formValues.backupRetention });
      await updateSetting.mutateAsync({ key: "cloud_backup", value: formValues.cloudBackup.toString() });
      
      toast({
        title: "Settings saved",
        description: "Backup settings have been updated successfully."
      });
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your backup settings.",
        variant: "destructive"
      });
    }
  };
  
  const handleBackupNow = async () => {
    setBackupInProgress(true);
    
    try {
      // Simulate backup process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Record the backup in sync history
      await createSyncHistory.mutateAsync({
        syncType: "backup",
        recordsProcessed: 284, // Example number of records
        durationSeconds: Math.floor(Math.random() * 60) + 20, // Random duration between 20-80 seconds
        status: "completed",
        errorMessage: ""
      });
      
      toast({
        title: "Backup completed",
        description: "Your system data has been backed up successfully."
      });
    } catch (error) {
      toast({
        title: "Backup failed",
        description: "There was a problem creating the backup.",
        variant: "destructive"
      });
    } finally {
      setBackupInProgress(false);
    }
  };
  
  const handleRestore = async () => {
    setRestoreInProgress(true);
    
    try {
      // Simulate restore process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Restore completed",
        description: "Your system has been restored from the backup."
      });
    } catch (error) {
      toast({
        title: "Restore failed",
        description: "There was a problem restoring from backup.",
        variant: "destructive"
      });
    } finally {
      setRestoreInProgress(false);
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="border-b">
          <CardTitle>Backup & Restore</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center items-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Backup & Restore</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Manage system backups
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="space-y-4">
          <div>
            <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Backup Frequency</Label>
            <Select
              value={formValues.backupFrequency}
              onValueChange={(value) => setFormValues({...formValues, backupFrequency: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hourly">Hourly</SelectItem>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="block text-sm font-medium mb-1 dark:text-gray-300">Backup Retention</Label>
            <Select
              value={formValues.backupRetention}
              onValueChange={(value) => setFormValues({...formValues, backupRetention: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select retention period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">7 days</SelectItem>
                <SelectItem value="30">30 days</SelectItem>
                <SelectItem value="90">90 days</SelectItem>
                <SelectItem value="365">365 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center justify-between p-3 border rounded-md dark:border-gray-700">
            <div>
              <p className="font-medium dark:text-white">Cloud Backup</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Store backups in the cloud</p>
            </div>
            <Switch 
              checked={formValues.cloudBackup} 
              onCheckedChange={(checked) => setFormValues({...formValues, cloudBackup: checked})}
            />
          </div>
          
          <div className="grid grid-cols-1 gap-2 pt-3">
            <Button 
              className="w-full bg-primary text-white" 
              onClick={handleBackupNow}
              disabled={backupInProgress}
            >
              {backupInProgress ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-2 h-4 w-4" />
              )}
              Backup Now
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full"
              onClick={handleRestore}
              disabled={restoreInProgress}
            >
              {restoreInProgress ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Upload className="mr-2 h-4 w-4" />
              )}
              Restore From Backup
            </Button>
          </div>
          
          <div className="flex justify-end pt-4">
            <Button 
              onClick={handleSaveChanges}
              disabled={updateSetting.isPending}
              variant="outline"
            >
              {updateSetting.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Settings
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BackupRestore;

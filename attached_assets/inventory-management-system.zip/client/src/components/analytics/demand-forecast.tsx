import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { useBatchDemandForecasts, useProducts } from "@/hooks/use-inventory";
import { Progress } from "@/components/ui/progress";
import { Loader2 } from "lucide-react";
import { getStatusColor } from "@/lib/utils";

const DemandForecast = () => {
  const [category, setCategory] = useState<string>("all");
  const [timePeriod, setTimePeriod] = useState<string>("7");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  
  const { data: products, isLoading: isLoadingProducts } = useProducts();
  const { data: forecasts, isLoading: isLoadingForecasts, refetch } = useBatchDemandForecasts(category === "all" ? undefined : category);
  
  const handleGenerateForecast = async () => {
    setIsGenerating(true);
    await refetch();
    setIsGenerating(false);
  };
  
  // Generate chart data from forecasts
  const chartData = [];
  if (forecasts && forecasts.length > 0) {
    const sampleForecast = forecasts[0];
    if (sampleForecast.forecast && sampleForecast.forecast.forecast) {
      // Create data for each day in the forecast
      for (let i = 0; i < sampleForecast.forecast.forecast.length; i++) {
        const dayData: any = { name: `Day ${i + 1}` };
        
        // Add each product's forecast for this day
        forecasts.forEach((productForecast, index) => {
          if (productForecast.forecast && productForecast.forecast.forecast) {
            const productName = productForecast.productName || `Product ${index}`;
            dayData[productName] = productForecast.forecast.forecast[i];
          }
        });
        
        chartData.push(dayData);
      }
    }
  }
  
  const isLoading = isLoadingProducts || isLoadingForecasts || isGenerating;
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Demand Forecasting</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Generate demand forecasts for products to optimize inventory levels
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium mb-1 dark:text-gray-300">Product Category</label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {!isLoadingProducts && products && [...new Set(products.map(p => p.category).filter(Boolean))].map(cat => (
                  <SelectItem key={cat} value={cat}>{cat || "Uncategorized"}</SelectItem>
                ))}
                {!isLoadingProducts && products && products.some(p => !p.category) && (
                  <SelectItem value="uncategorized">Uncategorized</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1 dark:text-gray-300">Time Period</label>
            <Select value={timePeriod} onValueChange={setTimePeriod}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select time period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Next 7 days</SelectItem>
                <SelectItem value="14">Next 14 days</SelectItem>
                <SelectItem value="30">Next 30 days</SelectItem>
                <SelectItem value="90">Next 90 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button 
            onClick={handleGenerateForecast} 
            disabled={isLoading}
            className="bg-primary text-white"
          >
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Generate Forecast
          </Button>
        </div>
      </CardContent>
      
      <div className="border-t p-4">
        <div className="mb-4 flex justify-between items-center">
          <h4 className="font-medium dark:text-white">Forecast Results</h4>
          <div className="flex items-center text-sm">
            <span className="text-gray-500 dark:text-gray-400 mr-2">Method:</span>
            <span className="font-medium dark:text-white">
              {forecasts && forecasts[0]?.forecast?.method || "Moving Average with Trend Analysis"}
            </span>
          </div>
        </div>
        
        {/* Chart for forecast visualization */}
        {!isLoading && chartData.length > 0 && (
          <div className="h-64 mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                {forecasts && forecasts.slice(0, 5).map((productForecast, index) => (
                  <Line
                    key={productForecast.productId}
                    type="monotone"
                    dataKey={productForecast.productName}
                    stroke={index === 0 ? "#3f51b5" : index === 1 ? "#f50057" : index === 2 ? "#ff9800" : "#4caf50"}
                    activeDot={{ r: 8 }}
                    strokeWidth={2}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product ID</TableHead>
                <TableHead>Product Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Current Stock</TableHead>
                <TableHead>Forecasted Demand</TableHead>
                <TableHead>Confidence</TableHead>
                <TableHead>Stock Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                  </TableCell>
                </TableRow>
              ) : forecasts && forecasts.length > 0 ? (
                forecasts.map((forecast) => {
                  const avgDemand = forecast.forecast?.forecast ? 
                    Math.round(forecast.forecast.forecast.reduce((sum, val) => sum + val, 0) / forecast.forecast.forecast.length) 
                    : 0;
                  
                  const status = forecast.currentStock > avgDemand * 2 
                    ? "Adequate" 
                    : forecast.currentStock < avgDemand 
                    ? "At Risk" 
                    : "Watch";
                  
                  const confidence = forecast.forecast?.confidence || 0;
                  
                  return (
                    <TableRow key={forecast.productId}>
                      <TableCell>PRD-{forecast.productId}</TableCell>
                      <TableCell>{forecast.productName}</TableCell>
                      <TableCell>{forecast.category || "Uncategorized"}</TableCell>
                      <TableCell>{forecast.currentStock}</TableCell>
                      <TableCell>{avgDemand} units</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div className="w-24 bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mr-2">
                            <div 
                              className={confidence > 0.75 ? "bg-green-500" : confidence > 0.6 ? "bg-yellow-500" : "bg-red-500"} 
                              style={{ width: `${confidence * 100}%`, height: "0.625rem", borderRadius: "9999px" }}
                            ></div>
                          </div>
                          <span className="dark:text-white">{Math.round(confidence * 100)}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`text-xs py-1 px-2 rounded-full ${getStatusColor(status)}`}>
                          {status}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4 text-gray-500 dark:text-gray-400">
                    No forecast data available. Generate a forecast to see results.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        
        {forecasts && forecasts.length > 0 && (
          <div className="mt-4 flex justify-between">
            <Button variant="outline">Export Data</Button>
            <div className="flex space-x-2">
              <Button variant="outline">Previous</Button>
              <Button variant="default">Next</Button>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default DemandForecast;

import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { useInventoryAnomalies } from "@/hooks/use-inventory";
import { Loader2, AlertCircle } from "lucide-react";
import { getStatusColor } from "@/lib/utils";

const AnomalyDetection = () => {
  const { data: anomalies, isLoading, error, refetch } = useInventoryAnomalies();
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Inventory Anomaly Detection</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Identify unusual patterns in inventory data
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="flex justify-center items-center py-8 text-red-500">
            <AlertCircle className="h-8 w-8 mr-2" />
            <p>Error loading anomaly data</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product ID</TableHead>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Anomaly Type</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {anomalies && anomalies.length > 0 ? (
                  anomalies.map((anomaly) => (
                    <TableRow key={`${anomaly.productId}-${anomaly.anomalyType}`} className="hover:bg-gray-50 dark:hover:bg-gray-900">
                      <TableCell>PRD-{anomaly.productId}</TableCell>
                      <TableCell>{anomaly.productName}</TableCell>
                      <TableCell>
                        {anomaly.anomalyType === 'sudden_change' ? 'Sudden Change' : 
                         anomaly.anomalyType === 'data_gap' ? 'Data Gap' : 'Unexpected Zero'}
                      </TableCell>
                      <TableCell>
                        <span className={`py-1 px-2 text-xs rounded-full ${getStatusColor(anomaly.severity)}`}>
                          {anomaly.severity.charAt(0).toUpperCase() + anomaly.severity.slice(1)}
                        </span>
                      </TableCell>
                      <TableCell>{anomaly.details}</TableCell>
                      <TableCell>
                        <Button variant="link" className="text-primary p-0 h-auto">
                          Investigate
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500 dark:text-gray-400">
                      No anomalies detected in the current inventory data.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
        
        {anomalies && anomalies.length > 0 && (
          <div className="mt-4 flex justify-end">
            <Button onClick={() => refetch()} className="bg-primary text-white">
              Refresh Analysis
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AnomalyDetection;

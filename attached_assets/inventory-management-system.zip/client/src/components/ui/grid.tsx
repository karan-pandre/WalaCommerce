import { HTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export interface GridProps extends HTMLAttributes<HTMLDivElement> {
  columns?: number;
  gap?: number;
  children: React.ReactNode;
}

export const Grid = forwardRef<HTMLDivElement, GridProps>(
  ({ className, columns = 12, gap = 4, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "grid",
          `grid-cols-${columns}`,
          `gap-${gap}`,
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);
Grid.displayName = "Grid";

export interface GridItemProps extends HTMLAttributes<HTMLDivElement> {
  span?: number;
  colStart?: number;
  rowStart?: number;
  rowSpan?: number;
  children: React.ReactNode;
}

export const GridItem = forwardRef<HTMLDivElement, GridItemProps>(
  ({ className, span = 1, colStart, rowStart, rowSpan, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          `col-span-${span}`,
          colStart && `col-start-${colStart}`,
          rowStart && `row-start-${rowStart}`,
          rowSpan && `row-span-${rowSpan}`,
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);
GridItem.displayName = "GridItem";

import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  AlertTriangle, 
  Tag, 
  DollarSign, 
  Search, 
  Filter, 
  Loader2 
} from "lucide-react";
import { useReplenishmentSchedule, useCreatePurchaseOrder } from "@/hooks/use-inventory";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// Define urgency order for sorting
const urgencyOrder = { high: 0, medium: 1, low: 2 };

const RecommendationList = () => {
  const { data: recommendations, isLoading, error } = useReplenishmentSchedule();
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [filter, setFilter] = useState<string>("all");
  const createOrder = useCreatePurchaseOrder();
  const { toast } = useToast();

  const handleSelectItem = (productId: number) => {
    setSelectedItems(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId) 
        : [...prev, productId]
    );
  };

  const handleSelectAll = () => {
    if (filteredRecommendations && filteredRecommendations.length > 0) {
      if (selectedItems.length === filteredRecommendations.length) {
        setSelectedItems([]);
      } else {
        setSelectedItems(filteredRecommendations.map(rec => rec.productId));
      }
    }
  };

  const handleCreateOrder = async () => {
    if (selectedItems.length === 0) {
      toast({
        title: "No items selected",
        description: "Please select at least one item to create an order.",
        variant: "destructive"
      });
      return;
    }

    try {
      // Get selected recommendations
      const selectedRecs = recommendations?.filter(rec => selectedItems.includes(rec.productId)) || [];
      
      // Calculate totals
      const totalItems = selectedRecs.length;
      const totalValue = selectedRecs.reduce((sum, rec) => sum + (rec.recommendedQuantity * 50), 0); // Using dummy cost for demo
      
      // Create purchase order
      await createOrder.mutateAsync({
        poNumber: `PO-${new Date().getFullYear()}-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
        supplier: "Auto-Selected Supplier",
        itemCount: totalItems,
        totalValue,
        expectedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
        status: "processing"
      });
      
      toast({
        title: "Purchase order created",
        description: `Successfully created order with ${totalItems} items.`
      });
      
      // Clear selections
      setSelectedItems([]);
      
    } catch (err) {
      toast({
        title: "Failed to create order",
        description: "There was a problem creating the purchase order.",
        variant: "destructive"
      });
    }
  };

  // Filter recommendations
  const filteredRecommendations = recommendations?.filter(rec => {
    // Filter by search term
    const matchesSearch = 
      rec.productName.toLowerCase().includes(searchTerm.toLowerCase()) || 
      rec.productId.toString().includes(searchTerm);
      
    // Filter by urgency
    const matchesFilter = 
      filter === "all" || 
      (filter === "high" && rec.urgency === "high") ||
      (filter === "medium" && rec.urgency === "medium") ||
      (filter === "low" && rec.urgency === "low");
      
    return matchesSearch && matchesFilter;
  }).sort((a, b) => {
    // Sort by urgency and days until stockout
    if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
      return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
    }
    return a.daysUntilStockout - b.daysUntilStockout;
  });

  // Summary stats
  const highUrgencyCount = recommendations?.filter(r => r.urgency === "high").length || 0;
  const mediumUrgencyCount = recommendations?.filter(r => r.urgency === "medium").length || 0;
  const totalSavings = recommendations?.reduce((sum, rec) => sum + rec.costSavings, 0) || 0;

  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Replenishment Recommendations</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Smart recommendations for optimal stock levels
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="border rounded-md p-4 dark:border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-lg font-medium dark:text-white">{highUrgencyCount}</h4>
              <div className="bg-red-100 dark:bg-red-900 p-2 rounded-full">
                <AlertTriangle className="h-5 w-5 text-red-500 dark:text-red-300" />
              </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-sm">High Urgency</p>
          </div>
          
          <div className="border rounded-md p-4 dark:border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-lg font-medium dark:text-white">{mediumUrgencyCount}</h4>
              <div className="bg-yellow-100 dark:bg-yellow-900 p-2 rounded-full">
                <AlertTriangle className="h-5 w-5 text-yellow-500 dark:text-yellow-300" />
              </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-sm">Medium Urgency</p>
          </div>
          
          <div className="border rounded-md p-4 dark:border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-lg font-medium dark:text-white">{formatCurrency(totalSavings)}</h4>
              <div className="bg-green-100 dark:bg-green-900 p-2 rounded-full">
                <DollarSign className="h-5 w-5 text-green-500 dark:text-green-300" />
              </div>
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-sm">Potential Cost Savings</p>
          </div>
        </div>
        
        {/* Filters */}
        <div className="mb-4">
          <div className="flex flex-wrap justify-between items-center gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <Button 
                variant={filter === "all" ? "default" : "outline"} 
                size="sm"
                onClick={() => setFilter("all")}
              >
                All
              </Button>
              <Button 
                variant={filter === "high" ? "default" : "outline"} 
                size="sm"
                onClick={() => setFilter("high")}
              >
                High Urgency
              </Button>
              <Button 
                variant={filter === "medium" ? "default" : "outline"} 
                size="sm"
                onClick={() => setFilter("medium")}
              >
                Medium Urgency
              </Button>
              <Button 
                variant={filter === "low" ? "default" : "outline"} 
                size="sm"
                onClick={() => setFilter("low")}
              >
                Low Urgency
              </Button>
            </div>
            
            <div className="flex items-center">
              <div className="relative mr-2">
                <Input
                  type="text"
                  placeholder="Search products..."
                  className="border pl-8 pr-3 py-1 w-48 md:w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Search className="h-4 w-4 text-gray-500 absolute left-2 top-1/2 -translate-y-1/2" />
              </div>
              
              <Button variant="ghost" size="sm" className="text-primary">
                <Filter className="h-4 w-4 mr-1" />
                Filter
              </Button>
            </div>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-10">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="flex justify-center items-center py-10 text-red-500">
            <AlertTriangle className="h-8 w-8 mr-2" />
            <p>Error loading recommendations</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">
                    <Checkbox 
                      checked={
                        filteredRecommendations && 
                        filteredRecommendations.length > 0 && 
                        selectedItems.length === filteredRecommendations.length
                      }
                      onCheckedChange={handleSelectAll}
                      aria-label="Select all"
                    />
                  </TableHead>
                  <TableHead>Product ID</TableHead>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Current Stock</TableHead>
                  <TableHead>Recommended Qty</TableHead>
                  <TableHead>Expected Demand</TableHead>
                  <TableHead>Days Until Stockout</TableHead>
                  <TableHead>Lead Time</TableHead>
                  <TableHead>Urgency</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecommendations && filteredRecommendations.length > 0 ? (
                  filteredRecommendations.map((recommendation) => {
                    const isDanger = recommendation.daysUntilStockout <= recommendation.leadTimeDays;
                    
                    return (
                      <TableRow key={recommendation.productId}>
                        <TableCell>
                          <Checkbox 
                            checked={selectedItems.includes(recommendation.productId)}
                            onCheckedChange={() => handleSelectItem(recommendation.productId)}
                            aria-label={`Select ${recommendation.productName}`}
                          />
                        </TableCell>
                        <TableCell>PRD-{recommendation.productId}</TableCell>
                        <TableCell>{recommendation.productName}</TableCell>
                        <TableCell>{recommendation.currentStock}</TableCell>
                        <TableCell>{recommendation.recommendedQuantity}</TableCell>
                        <TableCell>{recommendation.expectedDemand} units (30 days)</TableCell>
                        <TableCell>
                          <span className={isDanger ? "text-red-500 font-medium" : "text-gray-500 dark:text-gray-400 font-medium"}>
                            {recommendation.daysUntilStockout} days
                          </span>
                        </TableCell>
                        <TableCell>{recommendation.leadTimeDays} days</TableCell>
                        <TableCell>
                          <span className={`
                            text-xs py-1 px-2 rounded-full
                            ${recommendation.urgency === 'high' 
                              ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300' 
                              : recommendation.urgency === 'medium'
                              ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                              : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                            }
                          `}>
                            {recommendation.urgency.charAt(0).toUpperCase() + recommendation.urgency.slice(1)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button 
                            size="sm"
                            variant={recommendation.urgency === 'high' ? 'default' : 'outline'} 
                            className={recommendation.urgency === 'high' ? "bg-primary text-white" : ""}
                            onClick={() => handleSelectItem(recommendation.productId)}
                          >
                            {recommendation.urgency === 'high' ? 'Order Now' : 'Add to Cart'}
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8 text-gray-500 dark:text-gray-400">
                      No recommendations found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
        
        {filteredRecommendations && filteredRecommendations.length > 0 && (
          <div className="mt-6 flex flex-wrap justify-between items-center gap-2">
            <div>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                Showing {filteredRecommendations.length} of {recommendations?.length || 0} products
              </span>
            </div>
            
            <div className="flex space-x-2">
              {selectedItems.length > 0 && (
                <Button className="bg-primary text-white mr-4" onClick={handleCreateOrder} disabled={createOrder.isPending}>
                  {createOrder.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Create Order ({selectedItems.length} items)
                </Button>
              )}
              
              <Button variant="outline">Previous</Button>
              <Button variant="default">1</Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">Next</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecommendationList;

import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { usePurchaseOrders } from "@/hooks/use-inventory";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import { Loader2, AlertTriangle } from "lucide-react";

const PurchaseOrders = () => {
  const { data: orders, isLoading, error } = usePurchaseOrders();
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Active Purchase Orders</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Track status of purchase orders created from recommendations
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="flex justify-center items-center py-8 text-red-500">
            <AlertTriangle className="h-8 w-8 mr-2" />
            <p>Error loading purchase orders</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>PO Number</TableHead>
                  <TableHead>Date Created</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total Value</TableHead>
                  <TableHead>Expected Delivery</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders && orders.length > 0 ? (
                  orders.map((order) => (
                    <TableRow key={order.id} className="hover:bg-gray-50 dark:hover:bg-gray-900">
                      <TableCell className="font-medium dark:text-gray-200">{order.poNumber}</TableCell>
                      <TableCell className="dark:text-gray-300">{formatDate(order.createdAt)}</TableCell>
                      <TableCell className="dark:text-gray-300">{order.supplier}</TableCell>
                      <TableCell className="dark:text-gray-300">{order.itemCount} products</TableCell>
                      <TableCell className="dark:text-gray-300">{formatCurrency(order.totalValue)}</TableCell>
                      <TableCell className="dark:text-gray-300">{formatDate(order.expectedDelivery)}</TableCell>
                      <TableCell>
                        <span className={`text-xs py-1 px-2 rounded-full ${getStatusColor(order.status)}`}>
                          {order.status.charAt(0).toUpperCase() + order.status.replace('_', ' ').slice(1)}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-gray-500 dark:text-gray-400">
                      No active purchase orders found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PurchaseOrders;

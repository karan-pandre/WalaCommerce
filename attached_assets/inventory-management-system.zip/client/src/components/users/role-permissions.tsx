import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Default permissions data
const defaultPermissions = {
  admin: {
    dashboard: { view: true, create: false, edit: false, delete: false, export: true },
    analytics: { view: true, create: true, edit: true, delete: true, export: true },
    replenishment: { view: true, create: true, edit: true, delete: true, export: true },
    sync: { view: true, create: true, edit: true, delete: true, export: true },
    users: { view: true, create: true, edit: true, delete: true, export: true },
    settings: { view: true, create: true, edit: true, delete: false, export: true }
  },
  manager: {
    dashboard: { view: true, create: false, edit: false, delete: false, export: true },
    analytics: { view: true, create: true, edit: true, delete: false, export: true },
    replenishment: { view: true, create: true, edit: true, delete: false, export: true },
    sync: { view: true, create: false, edit: false, delete: false, export: true },
    users: { view: true, create: false, edit: false, delete: false, export: true },
    settings: { view: true, create: false, edit: false, delete: false, export: false }
  },
  inventory_specialist: {
    dashboard: { view: true, create: false, edit: false, delete: false, export: true },
    analytics: { view: true, create: true, edit: false, delete: false, export: true },
    replenishment: { view: true, create: true, edit: true, delete: false, export: true },
    sync: { view: true, create: true, edit: false, delete: false, export: true },
    users: { view: false, create: false, edit: false, delete: false, export: false },
    settings: { view: false, create: false, edit: false, delete: false, export: false }
  },
  viewer: {
    dashboard: { view: true, create: false, edit: false, delete: false, export: false },
    analytics: { view: true, create: false, edit: false, delete: false, export: false },
    replenishment: { view: true, create: false, edit: false, delete: false, export: false },
    sync: { view: false, create: false, edit: false, delete: false, export: false },
    users: { view: false, create: false, edit: false, delete: false, export: false },
    settings: { view: false, create: false, edit: false, delete: false, export: false }
  }
};

const RolePermissions = () => {
  const [selectedRole, setSelectedRole] = useState<string>("admin");
  const [permissions, setPermissions] = useState(defaultPermissions);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();
  
  const handlePermissionChange = (module: string, permission: string, checked: boolean) => {
    setPermissions(prev => ({
      ...prev,
      [selectedRole]: {
        ...prev[selectedRole as keyof typeof prev],
        [module]: {
          ...prev[selectedRole as keyof typeof prev][module as keyof typeof prev[keyof typeof prev]],
          [permission]: checked
        }
      }
    }));
  };
  
  const handleSavePermissions = () => {
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      toast({
        title: "Permissions saved",
        description: `Permissions for ${selectedRole} role have been updated successfully.`
      });
    }, 1000);
  };
  
  const roleLabel = (role: string) => {
    switch (role) {
      case "admin": return "Admin";
      case "manager": return "Manager";
      case "inventory_specialist": return "Inventory Specialist";
      case "viewer": return "Viewer";
      default: return role;
    }
  };
  
  const modules = [
    { id: "dashboard", name: "Dashboard" },
    { id: "analytics", name: "Analytics" },
    { id: "replenishment", name: "Auto Replenishment" },
    { id: "sync", name: "Sync Configuration" },
    { id: "users", name: "User Management" },
    { id: "settings", name: "System Settings" }
  ];
  
  const permissionTypes = [
    { id: "view", label: "View" },
    { id: "create", label: "Create" },
    { id: "edit", label: "Edit" },
    { id: "delete", label: "Delete" },
    { id: "export", label: "Export" }
  ];
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>Role Permissions</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Configure access rights for each role
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="mb-4 flex justify-between items-center">
          <Select value={selectedRole} onValueChange={setSelectedRole}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin">Admin</SelectItem>
              <SelectItem value="manager">Manager</SelectItem>
              <SelectItem value="inventory_specialist">Inventory Specialist</SelectItem>
              <SelectItem value="viewer">Viewer</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            onClick={handleSavePermissions} 
            className="bg-primary text-white"
            disabled={isSaving}
          >
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Permissions
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <Table className="border dark:border-gray-700">
            <TableHeader className="bg-gray-50 dark:bg-gray-800">
              <TableRow>
                <TableHead className="py-3 px-4 border-b dark:border-gray-700">Module</TableHead>
                {permissionTypes.map(perm => (
                  <TableHead 
                    key={perm.id} 
                    className="py-3 px-4 border-b dark:border-gray-700 text-center"
                  >
                    {perm.label}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {modules.map(module => (
                <TableRow key={module.id} className="border-b dark:border-gray-700">
                  <TableCell className="py-3 px-4 font-medium dark:text-white">
                    {module.name}
                  </TableCell>
                  {permissionTypes.map(perm => {
                    const isNA = (module.id === "dashboard" && (perm.id === "create" || perm.id === "edit" || perm.id === "delete"));
                    
                    return (
                      <TableCell key={perm.id} className="py-3 px-4 text-center">
                        {isNA ? (
                          <span className="text-gray-400 dark:text-gray-600">N/A</span>
                        ) : (
                          <Checkbox
                            checked={
                              permissions[selectedRole as keyof typeof permissions]?.[
                                module.id as keyof typeof permissions[keyof typeof permissions]
                              ]?.[perm.id as keyof typeof permissions[keyof typeof permissions][keyof typeof permissions[keyof typeof permissions]]] || false
                            }
                            onCheckedChange={(checked) => 
                              handlePermissionChange(module.id, perm.id, checked as boolean)
                            }
                            aria-label={`${perm.label} ${module.name}`}
                          />
                        )}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default RolePermissions;

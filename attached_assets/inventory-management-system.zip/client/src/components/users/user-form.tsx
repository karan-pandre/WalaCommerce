import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useCreateUser, useUpdateUser, useUser } from "@/hooks/use-users";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface UserFormProps {
  selectedUserId: number | null;
  setSelectedUserId: (id: number | null) => void;
}

const UserForm = ({ selectedUserId, setSelectedUserId }: UserFormProps) => {
  const [formValues, setFormValues] = useState({
    fullName: "",
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    role: "viewer",
    isActive: true
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const { data: selectedUser, isLoading: isLoadingUser } = useUser(selectedUserId || 0);
  const createUser = useCreateUser();
  const updateUser = useUpdateUser();
  const { toast } = useToast();
  
  // Reset form when selectedUserId changes
  useEffect(() => {
    if (selectedUserId && selectedUser) {
      setFormValues({
        fullName: selectedUser.fullName || "",
        username: selectedUser.username,
        email: selectedUser.email || "",
        password: "",
        confirmPassword: "",
        role: selectedUser.role || "viewer",
        isActive: selectedUser.isActive
      });
    } else if (!selectedUserId) {
      // Reset form for new user
      setFormValues({
        fullName: "",
        username: "",
        email: "",
        password: "",
        confirmPassword: "",
        role: "viewer",
        isActive: true
      });
    }
  }, [selectedUserId, selectedUser]);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formValues.fullName.trim()) {
      newErrors.fullName = "Full name is required";
    }
    
    if (!formValues.username.trim()) {
      newErrors.username = "Username is required";
    } else if (formValues.username.length < 3) {
      newErrors.username = "Username must be at least 3 characters";
    }
    
    if (!formValues.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formValues.email)) {
      newErrors.email = "Email is invalid";
    }
    
    // Only validate password for new users or when changing password
    if (!selectedUserId) {
      if (!formValues.password) {
        newErrors.password = "Password is required";
      } else if (formValues.password.length < 6) {
        newErrors.password = "Password must be at least 6 characters";
      }
      
      if (formValues.password !== formValues.confirmPassword) {
        newErrors.confirmPassword = "Passwords do not match";
      }
    } else if (formValues.password && formValues.password !== formValues.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    try {
      if (selectedUserId) {
        // Update existing user
        const updateData: any = {
          fullName: formValues.fullName,
          email: formValues.email,
          role: formValues.role,
          isActive: formValues.isActive
        };
        
        // Only include password if it was changed
        if (formValues.password) {
          updateData.password = formValues.password;
        }
        
        await updateUser.mutateAsync({
          id: selectedUserId,
          data: updateData
        });
        
        toast({
          title: "User updated",
          description: "User has been updated successfully."
        });
      } else {
        // Create new user
        await createUser.mutateAsync({
          username: formValues.username,
          password: formValues.password,
          fullName: formValues.fullName,
          email: formValues.email,
          role: formValues.role,
          isActive: formValues.isActive
        });
        
        toast({
          title: "User created",
          description: "New user has been created successfully."
        });
        
        // Reset form
        setFormValues({
          fullName: "",
          username: "",
          email: "",
          password: "",
          confirmPassword: "",
          role: "viewer",
          isActive: true
        });
      }
      
      // Clear selection after successful operation
      setSelectedUserId(null);
    } catch (error) {
      toast({
        title: selectedUserId ? "Error updating user" : "Error creating user",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  };
  
  const handleCancel = () => {
    setSelectedUserId(null);
    setFormValues({
      fullName: "",
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
      role: "viewer",
      isActive: true
    });
    setErrors({});
  };
  
  const isLoading = isLoadingUser || createUser.isPending || updateUser.isPending;
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>{selectedUserId ? "Edit User" : "Add New User"}</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          {selectedUserId ? "Update user details and permissions" : "Create user account with appropriate permissions"}
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoadingUser ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <Label htmlFor="fullName" className="block text-sm font-medium mb-1 dark:text-gray-300">Full Name</Label>
                <Input
                  id="fullName"
                  type="text"
                  value={formValues.fullName}
                  onChange={(e) => setFormValues({...formValues, fullName: e.target.value})}
                  className={errors.fullName ? "border-red-500" : ""}
                />
                {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName}</p>}
              </div>
              
              <div>
                <Label htmlFor="username" className="block text-sm font-medium mb-1 dark:text-gray-300">Username</Label>
                <Input
                  id="username"
                  type="text"
                  value={formValues.username}
                  onChange={(e) => setFormValues({...formValues, username: e.target.value})}
                  disabled={!!selectedUserId} // Can't change username for existing users
                  className={errors.username ? "border-red-500" : ""}
                />
                {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username}</p>}
              </div>
              
              <div>
                <Label htmlFor="email" className="block text-sm font-medium mb-1 dark:text-gray-300">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={formValues.email}
                  onChange={(e) => setFormValues({...formValues, email: e.target.value})}
                  className={errors.email ? "border-red-500" : ""}
                />
                {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
              </div>
              
              <div>
                <Label htmlFor="role" className="block text-sm font-medium mb-1 dark:text-gray-300">Role</Label>
                <Select 
                  value={formValues.role} 
                  onValueChange={(value) => setFormValues({...formValues, role: value})}
                >
                  <SelectTrigger id="role">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="inventory_specialist">Inventory Specialist</SelectItem>
                    <SelectItem value="viewer">Viewer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="password" className="block text-sm font-medium mb-1 dark:text-gray-300">
                  {selectedUserId ? "New Password (leave blank to keep current)" : "Password"}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formValues.password}
                  onChange={(e) => setFormValues({...formValues, password: e.target.value})}
                  className={errors.password ? "border-red-500" : ""}
                />
                {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
              </div>
              
              <div>
                <Label htmlFor="confirmPassword" className="block text-sm font-medium mb-1 dark:text-gray-300">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formValues.confirmPassword}
                  onChange={(e) => setFormValues({...formValues, confirmPassword: e.target.value})}
                  className={errors.confirmPassword ? "border-red-500" : ""}
                />
                {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword}</p>}
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="isActive"
                  checked={formValues.isActive}
                  onCheckedChange={(checked) => setFormValues({...formValues, isActive: checked})}
                />
                <Label htmlFor="isActive" className="dark:text-gray-300">Account Active</Label>
              </div>
              
              <div className="flex space-x-2 pt-2">
                {selectedUserId && (
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancel
                  </Button>
                )}
                <Button 
                  type="submit" 
                  className="w-full bg-primary text-white"
                  disabled={isLoading}
                >
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {selectedUserId ? "Update User" : "Create User"}
                </Button>
              </div>
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  );
};

export default UserForm;

import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Search, Download, Loader2, AlertTriangle } from "lucide-react";
import { useUsers, useUpdateUser, useDeleteUser } from "@/hooks/use-users";
import { formatDateTime, getStatusColor } from "@/lib/utils";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

interface UserTableProps {
  onEditUser: (userId: number) => void;
}

const UserTable = ({ onEditUser }: UserTableProps) => {
  const { data: users, isLoading, error } = useUsers();
  const updateUser = useUpdateUser();
  const deleteUser = useDeleteUser();
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [userToDelete, setUserToDelete] = useState<number | null>(null);
  
  const filteredUsers = users?.filter(user => {
    const matchesSearch = 
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.fullName?.toLowerCase()?.includes(searchTerm.toLowerCase()) || false) ||
      (user.email?.toLowerCase()?.includes(searchTerm.toLowerCase()) || false);
      
    const matchesRole = roleFilter === "all" ? true : user.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });
  
  const handleToggleStatus = async (userId: number, currentStatus: boolean) => {
    try {
      await updateUser.mutateAsync({
        id: userId,
        data: { isActive: !currentStatus }
      });
      
      toast({
        title: currentStatus ? "User deactivated" : "User activated",
        description: `User has been ${currentStatus ? "deactivated" : "activated"} successfully.`
      });
    } catch (error) {
      toast({
        title: "Error updating user status",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  };
  
  const confirmDeleteUser = async () => {
    if (!userToDelete) return;
    
    try {
      await deleteUser.mutateAsync(userToDelete);
      
      toast({
        title: "User deleted",
        description: "User has been deleted successfully."
      });
      
      setUserToDelete(null);
    } catch (error) {
      toast({
        title: "Error deleting user",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    }
  };
  
  // Get role display based on role value
  const getRoleDisplay = (role: string) => {
    switch (role) {
      case "admin":
        return { text: "Admin", class: "bg-primary-100 text-primary-800 dark:bg-primary-900 dark:text-primary-300" };
      case "manager":
        return { text: "Manager", class: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300" };
      case "inventory_specialist":
        return { text: "Inventory Specialist", class: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300" };
      case "viewer":
        return { text: "Viewer", class: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300" };
      default:
        return { text: role, class: "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300" };
    }
  };
  
  // Generate initials from name
  const getInitials = (name: string) => {
    if (!name) return "?";
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };
  
  return (
    <Card>
      <CardHeader className="border-b">
        <CardTitle>User Accounts</CardTitle>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          Manage existing user accounts and permissions
        </p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="mb-4 flex flex-wrap justify-between items-center gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search users..."
                className="pl-8 w-48 md:w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="h-4 w-4 text-gray-500 absolute left-2 top-1/2 -translate-y-1/2" />
            </div>
            
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="All Roles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="inventory_specialist">Inventory Specialist</SelectItem>
                <SelectItem value="viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button variant="ghost" className="text-primary">
            <Download className="h-4 w-4 mr-1" />
            Export
          </Button>
        </div>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : error ? (
          <div className="flex justify-center items-center py-8 text-red-500">
            <AlertTriangle className="h-8 w-8 mr-2" />
            <p>Error loading users</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers && filteredUsers.length > 0 ? (
                  filteredUsers.map((user) => {
                    const roleInfo = getRoleDisplay(user.role);
                    
                    return (
                      <TableRow key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-900">
                        <TableCell>
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarImage src={`https://ui-avatars.com/api/?name=${encodeURIComponent(user.fullName || user.username)}&background=random`} />
                              <AvatarFallback>{getInitials(user.fullName || user.username)}</AvatarFallback>
                            </Avatar>
                            <span className="dark:text-white">{user.fullName || user.username}</span>
                          </div>
                        </TableCell>
                        <TableCell className="dark:text-gray-300">{user.email || "—"}</TableCell>
                        <TableCell>
                          <span className={`text-xs py-1 px-2 rounded-full ${roleInfo.class}`}>
                            {roleInfo.text}
                          </span>
                        </TableCell>
                        <TableCell className="dark:text-gray-300">
                          {user.lastLogin ? formatDateTime(user.lastLogin) : "Never"}
                        </TableCell>
                        <TableCell>
                          <span className={`text-xs py-1 px-2 rounded-full ${getStatusColor(user.isActive ? "active" : "inactive")}`}>
                            {user.isActive ? "Active" : "Inactive"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="link" className="p-0 h-auto text-primary" onClick={() => onEditUser(user.id)}>
                              Edit
                            </Button>
                            <span className="text-gray-300 dark:text-gray-600">|</span>
                            {user.isActive ? (
                              <Button 
                                variant="link" 
                                className="p-0 h-auto text-red-500"
                                onClick={() => handleToggleStatus(user.id, user.isActive)}
                                disabled={updateUser.isPending}
                              >
                                Deactivate
                              </Button>
                            ) : (
                              <Button 
                                variant="link" 
                                className="p-0 h-auto text-green-500"
                                onClick={() => handleToggleStatus(user.id, user.isActive)}
                                disabled={updateUser.isPending}
                              >
                                Activate
                              </Button>
                            )}
                            <span className="text-gray-300 dark:text-gray-600">|</span>
                            <AlertDialog open={userToDelete === user.id} onOpenChange={(open) => !open && setUserToDelete(null)}>
                              <AlertDialogTrigger asChild>
                                <Button 
                                  variant="link" 
                                  className="p-0 h-auto text-red-500"
                                  onClick={() => setUserToDelete(user.id)}
                                >
                                  Delete
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete the user account
                                    and remove the data from our servers.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={confirmDeleteUser}
                                    className="bg-red-500 hover:bg-red-600"
                                  >
                                    {deleteUser.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500 dark:text-gray-400">
                      No users found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UserTable;

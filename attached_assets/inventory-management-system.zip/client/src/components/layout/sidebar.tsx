import { useEffect } from "react";
import { useLocation } from "wouter";
import { 
  LayoutDashboard, 
  BarChart3, 
  Tags, 
  RefreshCw, 
  Users, 
  Settings
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAppContext } from "@/contexts/app-context";
import Header from "./header";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/" },
  { icon: BarChart3, label: "Analytics", href: "/analytics" },
  { icon: Tags, label: "Auto Replenishment", href: "/replenishment" },
  { icon: RefreshCw, label: "Sync Configuration", href: "/sync" },
  { icon: Users, label: "User Management", href: "/users" },
  { icon: Settings, label: "System Settings", href: "/settings" },
];

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const [location, setLocation] = useLocation();
  const { isSidebarOpen, toggleSidebar } = useAppContext();

  // Get the current page title
  const getCurrentTitle = () => {
    const activeItem = navItems.find((item) => item.href === location);
    return activeItem ? activeItem.label : "InventoryPro";
  };

  // Handle navigation
  const handleNavigation = (href: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setLocation(href);
  };

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      const sidebar = document.getElementById("sidebar");
      const menuButton = document.getElementById("menu-button");
      
      if (
        window.innerWidth < 1024 &&
        isSidebarOpen &&
        sidebar &&
        !sidebar.contains(target) &&
        menuButton &&
        !menuButton.contains(target)
      ) {
        toggleSidebar();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isSidebarOpen, toggleSidebar]);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950">
      <Header title={getCurrentTitle()} />

      {/* Sidebar Navigation */}
      <aside
        id="sidebar"
        className={cn(
          "fixed top-[53px] left-0 bottom-0 w-64 bg-white dark:bg-gray-900 shadow-md transition-transform duration-300 ease-in-out z-20",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <nav className="px-4 py-3">
          <div className="space-y-1">
            {navItems.map((item) => (
              <div
                key={item.href}
                onClick={handleNavigation(item.href)}
                className={cn(
                  "flex items-center w-full space-x-3 px-3 py-2 rounded-md cursor-pointer",
                  location === item.href
                    ? "bg-primary text-white dark:bg-primary/90"
                    : "hover:bg-gray-100 dark:hover:bg-gray-800 dark:text-gray-300"
                )}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main
        className={cn(
          "min-h-screen pt-[53px] transition-all duration-300",
          isSidebarOpen ? "lg:pl-64" : ""
        )}
      >
        <div className="p-4">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;

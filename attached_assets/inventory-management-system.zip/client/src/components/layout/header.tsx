import { useState } from "react";
import { 
  Bell, 
  Menu, 
  ChevronDown, 
  AlertTriangle, 
  Info, 
  User
} from "lucide-react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useAppContext } from "@/contexts/app-context";

interface HeaderProps {
  title: string;
}

const Header = ({ title }: HeaderProps) => {
  const { toggleSidebar } = useAppContext();
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm fixed top-0 left-0 right-0 z-10">
      <div className="flex justify-between items-center px-4 py-2">
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="lg:hidden"
          >
            <Menu className="h-6 w-6" />
          </Button>
          <h1 className="text-xl font-semibold text-primary dark:text-primary-foreground">
            InventoryPro
          </h1>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setIsNotificationsOpen(!isNotificationsOpen);
                setIsProfileOpen(false);
              }}
              className="relative"
            >
              <Bell className="h-6 w-6" />
              <span className="absolute top-1 right-1 bg-red-500 w-2 h-2 rounded-full"></span>
            </Button>

            {isNotificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-md shadow-lg p-4 z-50">
                <h3 className="font-semibold mb-2 dark:text-white">Notifications</h3>
                <div className="space-y-3">
                  <div className="flex items-start p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-md">
                    <div className="bg-red-100 dark:bg-red-900 p-2 rounded-md mr-3">
                      <AlertTriangle className="h-5 w-5 text-red-500 dark:text-red-300" />
                    </div>
                    <div>
                      <p className="text-sm font-medium dark:text-white">Stock Alert: Product ID #1242</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Inventory level below reorder point</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">2 minutes ago</p>
                    </div>
                  </div>

                  <div className="flex items-start p-2 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-md">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-md mr-3">
                      <Info className="h-5 w-5 text-blue-500 dark:text-blue-300" />
                    </div>
                    <div>
                      <p className="text-sm font-medium dark:text-white">Sync Completed</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">All inventory data synchronized successfully</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">1 hour ago</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="relative">
            <button
              onClick={() => {
                setIsProfileOpen(!isProfileOpen);
                setIsNotificationsOpen(false);
              }}
              className="flex items-center space-x-2"
            >
              <Avatar>
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                <AvatarFallback>AU</AvatarFallback>
              </Avatar>
              <span className="hidden md:block text-sm dark:text-white">Admin User</span>
              <ChevronDown className="h-4 w-4 text-gray-500 dark:text-gray-400" />
            </button>

            {isProfileOpen && (
              <div 
                className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-50"
                onClick={() => setIsProfileOpen(false)}
              >
                <a href="#profile" className="block px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white">
                  Profile
                </a>
                <a href="#settings" className="block px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white">
                  Settings
                </a>
                <hr className="my-1 dark:border-gray-700" />
                <a href="#logout" className="block px-4 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-white">
                  Sign out
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import GeneralSettings from "@/components/settings/general-settings";
import SystemInfo from "@/components/settings/system-info";
import InventorySettings from "@/components/settings/inventory-settings";
import BackupRestore from "@/components/settings/backup-restore";

const SystemSettings = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 dark:text-white">System Settings</h2>
      
      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid grid-cols-4 w-full max-w-3xl">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="backup">Backup</TabsTrigger>
          <TabsTrigger value="system">System Info</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="col-span-1 lg:col-span-2">
              <GeneralSettings />
            </div>
            <div className="col-span-1">
              <SystemInfo />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="inventory">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="col-span-1 lg:col-span-2">
              <InventorySettings />
            </div>
            <div className="col-span-1">
              <SystemInfo />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="backup">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="col-span-1 lg:col-span-2">
              <BackupRestore />
            </div>
            <div className="col-span-1">
              <SystemInfo />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="system">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="col-span-1 lg:col-span-2">
              <InventorySettings />
            </div>
            <div className="col-span-1">
              <SystemInfo />
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SystemSettings;

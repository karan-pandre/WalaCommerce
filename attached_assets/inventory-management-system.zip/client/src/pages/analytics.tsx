import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import DemandForecast from "@/components/analytics/demand-forecast";
import AnomalyDetection from "@/components/analytics/anomaly-detection";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Analytics = () => {
  const [activeTab, setActiveTab] = useState<string>("forecast");

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 dark:text-white">Analytics</h2>
      
      <Tabs defaultValue="forecast" onValueChange={setActiveTab} value={activeTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="forecast">Demand Forecasting</TabsTrigger>
          <TabsTrigger value="anomalies">Anomaly Detection</TabsTrigger>
        </TabsList>
        
        <TabsContent value="forecast" className="mt-0">
          <DemandForecast />
        </TabsContent>
        
        <TabsContent value="anomalies" className="mt-0">
          <AnomalyDetection />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Analytics;

import { useState } from "react";
import { 
  Grid, 
  GridItem 
} from "@/components/ui/grid";
import UserForm from "@/components/users/user-form";
import UserTable from "@/components/users/user-table";
import RolePermissions from "@/components/users/role-permissions";

const UserManagement = () => {
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 dark:text-white">User Management</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {/* User Form */}
        <div className="col-span-1">
          <UserForm selectedUserId={selectedUserId} setSelectedUserId={setSelectedUserId} />
        </div>
        
        {/* User Table */}
        <div className="col-span-1 lg:col-span-2">
          <UserTable onEditUser={setSelectedUserId} />
        </div>
      </div>
      
      {/* Role Permissions */}
      <RolePermissions />
    </div>
  );
};

export default UserManagement;

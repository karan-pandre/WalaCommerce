import { LayoutDashboard, Package, AlertTriangle, ShoppingCart, DollarSign } from "lucide-react";
import { useDashboardStats } from "@/hooks/use-inventory";
import StatsCard from "@/components/dashboard/stats-card";
import DemandChart from "@/components/dashboard/demand-chart";
import InventoryBreakdown from "@/components/dashboard/inventory-breakdown";
import ActivityTable from "@/components/dashboard/activity-table";
import { formatCurrency } from "@/lib/utils";

const Dashboard = () => {
  const { data, isLoading, error } = useDashboardStats();

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 dark:text-white">Dashboard</h2>
      
      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="Total Products"
          value={isLoading ? "..." : data?.totalProducts || 0}
          change={{ value: 3.2, type: "increase" }}
          icon={<Package className="h-5 w-5 text-primary" />}
          iconBgClass="bg-primary/10"
        />
        
        <StatsCard
          title="Low Stock Items"
          value={isLoading ? "..." : data?.lowStockItems || 0}
          change={{ value: 12.5, type: "increase", label: "from last week" }}
          icon={<AlertTriangle className="h-5 w-5 text-warning" />}
          iconBgClass="bg-warning/10"
        />
        
        <StatsCard
          title="Pending Orders"
          value={isLoading ? "..." : data?.pendingOrders || 0}
          change={{ value: 8.3, type: "decrease", label: "from last week" }}
          icon={<ShoppingCart className="h-5 w-5 text-info" />}
          iconBgClass="bg-info/10"
        />
        
        <StatsCard
          title="Inventory Value"
          value={isLoading ? "..." : formatCurrency(data?.inventoryValue || 0)}
          change={{ value: 5.7, type: "increase" }}
          icon={<DollarSign className="h-5 w-5 text-secondary" />}
          iconBgClass="bg-secondary/10"
        />
      </div>
      
      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <DemandChart />
        <InventoryBreakdown />
      </div>
      
      {/* Activity Table */}
      <ActivityTable />
    </div>
  );
};

export default Dashboard;

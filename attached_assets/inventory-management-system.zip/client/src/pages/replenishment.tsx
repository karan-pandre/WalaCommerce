import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import RecommendationList from "@/components/replenishment/recommendation-list";
import PurchaseOrders from "@/components/replenishment/purchase-orders";

const Replenishment = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 dark:text-white">Auto Replenishment</h2>
      
      <div className="space-y-6">
        {/* Replenishment Recommendations */}
        <RecommendationList />
        
        {/* Purchase Orders */}
        <PurchaseOrders />
      </div>
    </div>
  );
};

export default Replenishment;

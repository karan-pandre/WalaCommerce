import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import SyncSettings from "@/components/sync/sync-settings";
import SyncHistory from "@/components/sync/sync-history";

const SyncConfig = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4 dark:text-white">Sync Configuration</h2>
      
      <div className="space-y-6">
        {/* Sync Settings */}
        <SyncSettings />
        
        {/* Sync History */}
        <SyncHistory />
      </div>
    </div>
  );
};

export default SyncConfig;

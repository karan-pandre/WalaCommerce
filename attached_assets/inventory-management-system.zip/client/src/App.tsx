import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Layout from "@/components/layout/sidebar";
import Dashboard from "@/pages/dashboard";
import Analytics from "@/pages/analytics";
import Replenishment from "@/pages/replenishment";
import SyncConfig from "@/pages/sync";
import UserManagement from "@/pages/users";
import SystemSettings from "@/pages/settings";
import { AppProvider } from "./contexts/app-context";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/replenishment" component={Replenishment} />
      <Route path="/sync" component={SyncConfig} />
      <Route path="/users" component={UserManagement} />
      <Route path="/settings" component={SystemSettings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppProvider>
        <Layout>
          <Router />
        </Layout>
        <Toaster />
      </AppProvider>
    </QueryClientProvider>
  );
}

export default App;

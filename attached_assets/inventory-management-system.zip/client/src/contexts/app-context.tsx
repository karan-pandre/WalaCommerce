import React, { createContext, useContext, useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { Setting } from "@shared/schema";

interface AppContextType {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  settings: Map<string, string>;
  updateSetting: (key: string, value: string) => Promise<void>;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 1024);
  const [settings, setSettings] = useState<Map<string, string>>(new Map());
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    function handleResize() {
      setIsSidebarOpen(window.innerWidth >= 1024);
    }

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    // Fetch settings
    const fetchSettings = async () => {
      try {
        const response = await fetch("/api/settings");
        if (response.ok) {
          const data = await response.json() as Setting[];
          const settingsMap = new Map<string, string>();
          data.forEach((setting) => {
            settingsMap.set(setting.key, setting.value || "");
          });
          setSettings(settingsMap);
          
          // Check dark mode setting
          if (settingsMap.get("dark_mode") === "true") {
            setIsDarkMode(true);
            document.documentElement.classList.add("dark");
          }
        }
      } catch (error) {
        console.error("Failed to fetch settings:", error);
      }
    };

    fetchSettings();
  }, []);

  const toggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  const updateSetting = async (key: string, value: string) => {
    try {
      const response = await apiRequest("PATCH", `/api/settings/${key}`, { value });
      if (response.ok) {
        const updatedSetting = await response.json();
        setSettings((prev) => {
          const newSettings = new Map(prev);
          newSettings.set(key, updatedSetting.value);
          return newSettings;
        });
        
        // Handle dark mode toggle
        if (key === "dark_mode") {
          setIsDarkMode(value === "true");
          if (value === "true") {
            document.documentElement.classList.add("dark");
          } else {
            document.documentElement.classList.remove("dark");
          }
        }
      }
    } catch (error) {
      console.error(`Failed to update setting ${key}:`, error);
      throw error;
    }
  };

  const toggleDarkMode = async () => {
    const newValue = (!isDarkMode).toString();
    await updateSetting("dark_mode", newValue);
  };

  const value = {
    isSidebarOpen,
    toggleSidebar,
    settings,
    updateSetting,
    isDarkMode,
    toggleDarkMode,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider");
  }
  return context;
}

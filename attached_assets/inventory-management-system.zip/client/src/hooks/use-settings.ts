import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Setting } from "@shared/schema";

export function useSettings() {
  return useQuery<Setting[]>({
    queryKey: ["/api/settings"],
  });
}

export function useSettingsByCategory(category: string) {
  return useQuery<Setting[]>({
    queryKey: [`/api/settings/${category}`],
    enabled: !!category,
  });
}

export function useUpdateSetting() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ key, value }: { key: string, value: string }) => {
      const res = await apiRequest("PATCH", `/api/settings/${key}`, { value });
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      queryClient.invalidateQueries({ queryKey: [`/api/settings/${variables.key}`] });
      toast({
        title: "Setting updated",
        description: "Your settings have been saved successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating setting",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    },
  });
}

export function useSyncHistory(limit: number = 10) {
  return useQuery({
    queryKey: [`/api/sync/history?limit=${limit}`],
  });
}

export function useCreateSyncHistoryEntry() {
  return useMutation({
    mutationFn: async (data: {
      syncType: string;
      recordsProcessed: number;
      durationSeconds: number;
      status: string;
      errorMessage?: string;
    }) => {
      const res = await apiRequest("POST", "/api/sync/history", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sync/history"] });
    },
  });
}

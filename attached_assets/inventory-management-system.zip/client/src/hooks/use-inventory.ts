import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Product, 
  Inventory, 
  DemandForecast, 
  InventoryAnomaly, 
  ReplenishmentRecommendation 
} from "@shared/schema";

export function useProducts() {
  return useQuery({
    queryKey: ["/api/products"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

export function useProduct(id: number) {
  return useQuery({
    queryKey: [`/api/products/${id}`],
    enabled: !!id,
  });
}

export function useInventoryActivities(limit: number = 10) {
  return useQuery({
    queryKey: [`/api/inventory/activities?limit=${limit}`],
  });
}

export function useCreateProduct() {
  return useMutation({
    mutationFn: async (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => {
      const res = await apiRequest("POST", "/api/products", product);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });
}

export function useUpdateProduct() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<Product> }) => {
      const res = await apiRequest("PATCH", `/api/products/${id}`, data);
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: [`/api/products/${variables.id}`] });
    },
  });
}

export function useCreateInventoryActivity() {
  return useMutation({
    mutationFn: async (inventory: Omit<Inventory, 'id' | 'lastUpdated'>) => {
      const res = await apiRequest("POST", "/api/inventory", inventory);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
  });
}

export function useDemandForecast(productId: number) {
  return useQuery({
    queryKey: [`/api/analytics/forecast/${productId}`],
    enabled: !!productId,
  });
}

export function useBatchDemandForecasts(category?: string) {
  const url = category 
    ? `/api/analytics/forecasts?category=${category}`
    : `/api/analytics/forecasts`;
    
  return useQuery({
    queryKey: [url],
  });
}

export function useInventoryAnomalies() {
  return useQuery({
    queryKey: ["/api/analytics/anomalies"],
  });
}

export function useReplenishmentRecommendation(productId: number) {
  return useQuery<ReplenishmentRecommendation & { productName: string, category: string }>({
    queryKey: [`/api/analytics/replenishment/${productId}`],
    enabled: !!productId,
  });
}

export function useReplenishmentSchedule() {
  return useQuery<(ReplenishmentRecommendation & { productName: string, category: string })[]>({
    queryKey: ["/api/analytics/replenishment-schedule"],
  });
}

export function usePurchaseOrders() {
  return useQuery({
    queryKey: ["/api/purchase-orders"],
  });
}

export function useCreatePurchaseOrder() {
  return useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/purchase-orders", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/purchase-orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
  });
}

export function useDashboardStats() {
  return useQuery({
    queryKey: ["/api/dashboard/stats"],
  });
}

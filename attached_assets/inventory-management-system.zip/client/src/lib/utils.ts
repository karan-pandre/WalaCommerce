import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
}

export function formatDate(date: Date | string): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }).format(date);
}

export function formatDateTime(date: Date | string): string {
  if (typeof date === 'string') {
    date = new Date(date);
  }
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  }).format(date);
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function calculatePercentageChange(current: number, previous: number): number {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
}

export function getRandomColor(index: number): string {
  const colors = [
    'hsl(222.2, 47.4%, 11.2%)', // primary
    'hsl(346, 100%, 47%)',      // secondary
    'hsl(36, 100%, 50%)',       // warning
    'hsl(210, 100%, 50%)',      // info
    'hsl(120, 100%, 30%)',      // success
    'hsl(0, 100%, 50%)',        // error
    'hsl(280, 80%, 50%)',       // purple
    'hsl(170, 80%, 40%)'        // teal
  ];
  
  return colors[index % colors.length];
}

export function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case 'completed':
    case 'active':
    case 'success':
    case 'adequate':
      return 'bg-green-100 text-green-800';
    case 'processing':
    case 'in progress':
    case 'watch':
    case 'medium':
      return 'bg-yellow-100 text-yellow-800';
    case 'failed':
    case 'error':
    case 'at risk':
    case 'high':
      return 'bg-red-100 text-red-800';
    case 'in transit':
    case 'verified':
    case 'info':
      return 'bg-blue-100 text-blue-800';
    case 'inactive':
    case 'cancelled':
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

export function getUrgencyColor(urgency: 'high' | 'medium' | 'low'): string {
  switch (urgency) {
    case 'high': 
      return 'bg-red-100 text-red-800';
    case 'medium': 
      return 'bg-yellow-100 text-yellow-800';
    case 'low': 
      return 'bg-green-100 text-green-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

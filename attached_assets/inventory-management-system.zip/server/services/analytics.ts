import type { Product, Inventory, DemandForecast, InventoryAnomaly, ReplenishmentRecommendation, SyncFrequencyRecommendation } from "@shared/schema";

// -----------------------------------------------------------------
// ------------------- MODULE 1: DEMAND FORECASTING ----------------
// -----------------------------------------------------------------

// Generate a simple demand forecast without using TensorFlow.js
// This is a simplified version for the server
export async function generateDemandForecast(product: Product, historicalDemand: number[] = []): Promise<DemandForecast> {
  // Use historical data or generate placeholder data
  const dataToUse = historicalDemand.length > 0 ? historicalDemand : generatePlaceholderDemandData(product);
  
  // Simple moving average method
  const movingAverage = calculateMovingAverage(dataToUse, 5);
  
  // Generate 7-day forecast using trend analysis
  const forecast = [];
  let lastValue = movingAverage;
  
  // Detect trend from historical data
  const trendFactor = detectTrend(dataToUse);
  
  // Generate forecast applying trend
  for (let i = 0; i < 7; i++) {
    // Add some randomness while following the trend
    const nextValue = Math.max(0, Math.round(lastValue * (1 + trendFactor) * (0.9 + Math.random() * 0.2)));
    forecast.push(nextValue);
    lastValue = nextValue;
  }
  
  return {
    forecast,
    confidence: 0.7 + Math.random() * 0.15, // Simulated confidence level
    method: "Moving Average with Trend Analysis"
  };
}

// Helper function to generate placeholder demand data
function generatePlaceholderDemandData(product: Product): number[] {
  const baseValue = (product.stockQuantity + product.reorderPoint) / 2;
  return Array(30).fill(0).map(() => 
    Math.max(1, Math.round(baseValue * (0.7 + Math.random() * 0.6))) // Random values between 70% and 130% of base
  );
}

// Calculate moving average
function calculateMovingAverage(data: number[], windowSize: number): number {
  if (data.length === 0) return 0;
  
  const windowData = data.slice(-windowSize);
  const sum = windowData.reduce((acc, val) => acc + val, 0);
  return sum / windowData.length;
}

// Detect trend in data
function detectTrend(data: number[]): number {
  if (data.length < 2) return 0;
  
  // Use simple linear regression to detect trend
  const n = data.length;
  const xValues = Array.from({ length: n }, (_, i) => i);
  
  const xMean = xValues.reduce((sum, x) => sum + x, 0) / n;
  const yMean = data.reduce((sum, y) => sum + y, 0) / n;
  
  let numerator = 0;
  let denominator = 0;
  
  for (let i = 0; i < n; i++) {
    numerator += (xValues[i] - xMean) * (data[i] - yMean);
    denominator += Math.pow(xValues[i] - xMean, 2);
  }
  
  // Prevent division by zero
  if (denominator === 0) return 0;
  
  const slope = numerator / denominator;
  
  // Normalize slope to a small percentage for forecasting
  return slope / (yMean * 10);
}

// -----------------------------------------------------------------
// ----------- MODULE 2: REAL-TIME STOCK SYNCHRONIZATION -----------
// -----------------------------------------------------------------

// Detect anomalies in inventory data
export function detectInventoryAnomalies(inventoryHistory: Inventory[]): InventoryAnomaly[] {
  const anomalies: InventoryAnomaly[] = [];
  
  // Group by product
  const productGroups = new Map<number, Inventory[]>();
  inventoryHistory.forEach(item => {
    if (!productGroups.has(item.productId)) {
      productGroups.set(item.productId, []);
    }
    const group = productGroups.get(item.productId);
    if (group) {
      group.push(item);
    }
  });
  
  // Check each product's history for anomalies
  productGroups.forEach((history, productId) => {
    // Sort by lastUpdated date
    history.sort((a, b) => 
      new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime()
    );
    
    // Check for sudden changes
    for (let i = 1; i < history.length; i++) {
      const prev = history[i-1];
      const current = history[i];
      
      // Skip if either quantity is zero (handled by unexpected_zero check)
      if (prev.quantity === 0 || current.quantity === 0) continue;
      
      const changePercent = Math.abs(current.quantity - prev.quantity) / prev.quantity * 100;
      
      if (changePercent > 50 && Math.abs(current.quantity - prev.quantity) > 10) {
        anomalies.push({
          productId,
          anomalyType: 'sudden_change',
          severity: changePercent > 80 ? 'high' : 'medium',
          details: `Sudden ${current.quantity > prev.quantity ? 'increase' : 'decrease'} of ${Math.abs(current.quantity - prev.quantity)} units (${changePercent.toFixed(1)}%)`
        });
      }
      
      // Check for unexpected zero
      if (prev.quantity > 10 && current.quantity === 0) {
        anomalies.push({
          productId,
          anomalyType: 'unexpected_zero',
          severity: 'high',
          details: `Unexpected drop to zero from ${prev.quantity} units`
        });
      }
    }
  });
  
  return anomalies;
}

// Recommend sync frequency based on inventory turnover
export function recommendSyncFrequency(
  product: Product, 
  inventoryHistory: Inventory[]
): SyncFrequencyRecommendation {
  // Calculate inventory turnover
  const turnoverRate = estimateProductTurnoverRate(product, inventoryHistory);
  
  if (turnoverRate >= 0.1) { // High turnover (>= 10% per day)
    return {
      frequency: 'hourly',
      reasoning: 'High turnover rate detected. Stock changes rapidly, requiring frequent updates.'
    };
  } else if (turnoverRate >= 0.05) { // Medium turnover (>= 5% per day)
    return {
      frequency: 'daily',
      reasoning: 'Moderate turnover rate. Daily synchronization provides sufficient accuracy.'
    };
  } else { // Low turnover
    return {
      frequency: 'weekly',
      reasoning: 'Low turnover rate. Stock levels change slowly. Weekly sync is adequate.'
    };
  }
}

// Helper to estimate product turnover rate
function estimateProductTurnoverRate(product: Product, inventoryHistory: Inventory[]): number {
  if (inventoryHistory.length < 2) {
    // Not enough history, estimate based on reorder point
    return product.reorderPoint / (product.stockQuantity || 1) / 30; // Rough daily rate
  }
  
  // Calculate average daily change
  const history = [...inventoryHistory].sort((a, b) => 
    new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime()
  );
  
  let totalDecreasePerDay = 0;
  let dataPointCount = 0;
  
  for (let i = 1; i < history.length; i++) {
    const prev = history[i-1];
    const current = history[i];
    
    const daysDifference = (new Date(current.lastUpdated).getTime() - new Date(prev.lastUpdated).getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysDifference > 0 && current.quantity < prev.quantity) {
      const decreasePerDay = (prev.quantity - current.quantity) / daysDifference;
      totalDecreasePerDay += decreasePerDay;
      dataPointCount++;
    }
  }
  
  if (dataPointCount === 0) return 0.01; // Default low rate
  
  const avgDecreasePerDay = totalDecreasePerDay / dataPointCount;
  return avgDecreasePerDay / (product.stockQuantity || 1); // Rate as a percentage of current stock
}

// -----------------------------------------------------------------
// -------------- MODULE 3: AUTOMATED REPLENISHMENT ---------------
// -----------------------------------------------------------------

// Calculate replenishment recommendation
export async function calculateReplenishmentRecommendation(
  product: Product,
  historicalDemand: number[] = [],
  leadTimeDays: number = 5,
  orderCost: number = 20,
  holdingCostPercent: number = 0.25
): Promise<ReplenishmentRecommendation> {
  // Generate forecast
  const forecast = await generateDemandForecast(product, historicalDemand);
  
  // Calculate average daily demand from forecast
  const avgDailyDemand = forecast.forecast.reduce((sum, val) => sum + val, 0) / forecast.forecast.length;
  
  // Calculate annual demand estimate
  const annualDemand = avgDailyDemand * 365;
  
  // Calculate holding cost per unit
  const holdingCost = product.cost * holdingCostPercent;
  
  // Calculate EOQ
  const eoq = calculateEOQ(annualDemand, orderCost, holdingCost);
  
  // Calculate days until stockout
  const daysUntilStockout = avgDailyDemand > 0 ? product.stockQuantity / avgDailyDemand : 365;
  
  // Determine urgency
  let urgency: 'high' | 'medium' | 'low';
  if (daysUntilStockout <= leadTimeDays) {
    urgency = 'high';
  } else if (daysUntilStockout <= leadTimeDays * 2) {
    urgency = 'medium';
  } else {
    urgency = 'low';
  }
  
  // Calculate recommended quantity
  let recommendedQuantity: number;
  
  if (urgency === 'high') {
    // For high urgency, order enough to cover immediate needs plus safety stock
    recommendedQuantity = Math.max(
      eoq,
      avgDailyDemand * (leadTimeDays + 7) - product.stockQuantity
    );
  } else if (product.stockQuantity <= product.reorderPoint) {
    // If below reorder point but not high urgency, use EOQ
    recommendedQuantity = Math.round(eoq);
  } else {
    // Otherwise, no immediate replenishment needed
    recommendedQuantity = 0;
  }
  
  // Ensure recommended quantity is positive
  recommendedQuantity = Math.max(0, Math.round(recommendedQuantity));
  
  // Calculate potential cost savings (simplified)
  const regularOrderingCost = (annualDemand / (product.reorderPoint || 1)) * orderCost;
  const optimizedOrderingCost = (annualDemand / (eoq || 1)) * orderCost;
  const costSavings = regularOrderingCost - optimizedOrderingCost;
  
  return {
    productId: product.id,
    currentStock: product.stockQuantity,
    recommendedQuantity,
    urgency,
    expectedDemand: Math.round(avgDailyDemand * 30), // 30-day demand
    leadTimeDays,
    daysUntilStockout: Math.round(daysUntilStockout),
    costSavings: Math.round(costSavings)
  };
}

// Calculate EOQ (Economic Order Quantity)
function calculateEOQ(
  annualDemand: number,
  orderCost: number,
  holdingCost: number
): number {
  return Math.sqrt((2 * annualDemand * orderCost) / holdingCost);
}

// Generate replenishment schedule for multiple products
export async function generateReplenishmentSchedule(
  products: Product[],
  inventoryData: Inventory[]
): Promise<ReplenishmentRecommendation[]> {
  const recommendations: ReplenishmentRecommendation[] = [];
  
  for (const product of products) {
    // Calculate lead time based on product category (simplified)
    let leadTimeDays = 5; // Default
    if (product.isPerishable) {
      leadTimeDays = 2; // Perishable items have shorter lead time
    } else if (product.category === 'Electronics' || product.category === 'Apparel') {
      leadTimeDays = 7; // Longer lead time for these categories
    }
    
    // Calculate replenishment recommendation
    const recommendation = await calculateReplenishmentRecommendation(
      product,
      [], // Let the function handle historical demand derivation
      leadTimeDays
    );
    
    recommendations.push(recommendation);
  }
  
  // Sort by urgency and days until stockout
  return recommendations.sort((a, b) => {
    const urgencyOrder = { high: 0, medium: 1, low: 2 };
    if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
      return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
    }
    return a.daysUntilStockout - b.daysUntilStockout;
  });
}

// -----------------------------------------------------------------
// --------------- MODULE 4: PRODUCT CATEGORIZATION ---------------
// -----------------------------------------------------------------

// Batch categorize products
export function batchCategorizeProducts(products: Product[]): {
  product: Product;
  suggestion: {
    category: string;
    subcategory: string;
    confidence: number;
  };
}[] {
  return products
    .filter(product => !product.category || !product.subcategory)
    .map(product => {
      const categorization = categorizeProduct(product.name, product.description || '');
      return {
        product,
        suggestion: categorization
      };
    }).filter(result => result.suggestion.confidence > 0.6); // Only return confident suggestions
}

// Categorize a single product
function categorizeProduct(name: string, description: string): {
  category: string;
  subcategory: string;
  confidence: number;
} {
  const text = `${name} ${description}`.toLowerCase();
  
  // Define category keywords with weights
  const categories = [
    {
      name: 'Electronics',
      weight: 0,
      keywords: ['phone', 'smartphone', 'computer', 'laptop', 'tablet', 'electronic', 'gadget', 'device', 'charger', 'cable', 'headphone', 'speaker', 'earbuds', 'wireless', 'bluetooth', 'hdmi'],
      subcategories: [
        { name: 'Phones', keywords: ['phone', 'smartphone', 'iphone', 'android', 'mobile'] },
        { name: 'Computers', keywords: ['computer', 'laptop', 'desktop', 'pc', 'mac', 'keyboard', 'mouse'] },
        { name: 'Audio', keywords: ['headphone', 'speaker', 'earbuds', 'earphone', 'microphone', 'audio'] },
        { name: 'Accessories', keywords: ['charger', 'cable', 'adapter', 'case', 'cover', 'hdmi', 'usb', 'accessory'] }
      ]
    },
    {
      name: 'Clothing',
      weight: 0,
      keywords: ['shirt', 'pants', 'jacket', 'dress', 'clothing', 'apparel', 'wear', 'fashion', 'outfit', 'sock', 'underwear', 'sweater', 'hoodie', 'cotton', 'polyester'],
      subcategories: [
        { name: 'Tops', keywords: ['shirt', 't-shirt', 'blouse', 'top', 'sweater', 'sweatshirt', 'hoodie'] },
        { name: 'Bottoms', keywords: ['pants', 'jeans', 'shorts', 'skirt', 'trouser', 'leggings'] },
        { name: 'Outerwear', keywords: ['jacket', 'coat', 'cardigan', 'vest'] },
        { name: 'Underwear', keywords: ['underwear', 'socks', 'bra', 'boxer', 'brief'] }
      ]
    },
    {
      name: 'Home Goods',
      weight: 0,
      keywords: ['furniture', 'decor', 'lamp', 'light', 'kitchen', 'appliance', 'bedding', 'pillow', 'curtain', 'rug', 'towel', 'storage', 'organization', 'home'],
      subcategories: [
        { name: 'Furniture', keywords: ['chair', 'table', 'sofa', 'desk', 'bed', 'drawer', 'cabinet', 'shelf'] },
        { name: 'Lighting', keywords: ['lamp', 'light', 'bulb', 'led', 'fixture'] },
        { name: 'Kitchen', keywords: ['kitchen', 'cookware', 'utensil', 'plate', 'bowl', 'glass', 'mug', 'pan', 'pot'] },
        { name: 'Bedding', keywords: ['bedding', 'sheet', 'pillow', 'blanket', 'comforter', 'duvet', 'mattress'] }
      ]
    }
  ];
  
  // Count keyword occurrences for each category
  categories.forEach(category => {
    category.keywords.forEach(keyword => {
      if (text.includes(keyword)) {
        category.weight += 1;
      }
    });
  });
  
  // Find the category with the highest weight
  const bestCategory = categories.reduce((best, current) => 
    current.weight > best.weight ? current : best, categories[0]);
  
  // If no category has any weight, return unknown
  if (bestCategory.weight === 0) {
    return {
      category: 'Uncategorized',
      subcategory: '',
      confidence: 0
    };
  }
  
  // Calculate confidence (simplified)
  const totalWeight = categories.reduce((sum, cat) => sum + cat.weight, 0);
  const confidence = bestCategory.weight / totalWeight;
  
  // Find the best subcategory
  const subcategories = bestCategory.subcategories;
  subcategories.forEach(subcat => {
    subcat.weight = 0;
    subcat.keywords.forEach(keyword => {
      if (text.includes(keyword)) {
        subcat.weight += 1;
      }
    });
  });
  
  const bestSubcategory = subcategories.reduce((best, current) => 
    current.weight > best.weight ? current : best, { name: 'General', weight: 0, keywords: [] });
  
  return {
    category: bestCategory.name,
    subcategory: bestSubcategory.weight > 0 ? bestSubcategory.name : 'General',
    confidence: confidence
  };
}

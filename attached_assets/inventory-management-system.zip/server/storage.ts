import {
  users, type User, type InsertUser,
  products, type Product, type InsertProduct,
  inventory, type Inventory, type InsertInventory,
  settings, type Setting, type InsertSetting,
  syncHistory, type SyncHistory, type InsertSyncHistory,
  purchaseOrders, type PurchaseOrder, type InsertPurchaseOrder,
  type ReplenishmentRecommendation,
  type DemandForecast,
  type InventoryAnomaly,
  type SyncFrequencyRecommendation,
  type UserWithoutPassword
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<UserWithoutPassword[]>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Product operations
  getProduct(id: number): Promise<Product | undefined>;
  getProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Inventory operations
  getInventory(id: number): Promise<Inventory | undefined>;
  getInventoryByProductId(productId: number): Promise<Inventory[]>;
  getAllInventory(): Promise<Inventory[]>;
  createInventory(inventory: InsertInventory): Promise<Inventory>;
  getInventoryActivities(limit?: number): Promise<Inventory[]>;

  // Settings operations
  getSetting(key: string): Promise<Setting | undefined>;
  getSettingsByCategory(category: string): Promise<Setting[]>;
  getAllSettings(): Promise<Setting[]>;
  updateSetting(key: string, value: string): Promise<Setting | undefined>;

  // Sync history operations
  getSyncHistory(limit?: number): Promise<SyncHistory[]>;
  createSyncHistory(syncHistory: InsertSyncHistory): Promise<SyncHistory>;

  // Purchase orders
  getPurchaseOrders(): Promise<PurchaseOrder[]>;
  createPurchaseOrder(purchaseOrder: InsertPurchaseOrder): Promise<PurchaseOrder>;
  updatePurchaseOrder(id: number, data: Partial<InsertPurchaseOrder>): Promise<PurchaseOrder | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private inventoryItems: Map<number, Inventory>;
  private settingsMap: Map<string, Setting>;
  private syncHistoryItems: Map<number, SyncHistory>;
  private purchaseOrdersMap: Map<number, PurchaseOrder>;
  
  private userCurrentId: number;
  private productCurrentId: number;
  private inventoryCurrentId: number;
  private settingsCurrentId: number;
  private syncHistoryCurrentId: number;
  private purchaseOrderCurrentId: number;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.inventoryItems = new Map();
    this.settingsMap = new Map();
    this.syncHistoryItems = new Map();
    this.purchaseOrdersMap = new Map();
    
    this.userCurrentId = 1;
    this.productCurrentId = 1;
    this.inventoryCurrentId = 1;
    this.settingsCurrentId = 1;
    this.syncHistoryCurrentId = 1;
    this.purchaseOrderCurrentId = 1;
    
    // Init with default data
    this.seedDefaultData();
  }

  private seedDefaultData() {
    // Add an admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      fullName: "Admin User",
      email: "admin@example.com",
      role: "admin",
      isActive: true
    });

    // Add some sample products
    const products = [
      {
        name: "Smartphone X Pro",
        description: "Latest smartphone model with advanced features",
        category: "Electronics",
        subcategory: "Phones",
        stockQuantity: 15,
        reorderPoint: 10,
        cost: 400,
        price: 699.99,
        isPerishable: false
      },
      {
        name: "Wireless Earbuds",
        description: "Bluetooth 5.0 wireless earbuds with noise cancellation",
        category: "Electronics",
        subcategory: "Audio",
        stockQuantity: 62,
        reorderPoint: 20,
        cost: 45,
        price: 89.99,
        isPerishable: false
      },
      {
        name: "Desk Lamp",
        description: "Adjustable LED desk lamp with multiple brightness levels",
        category: "Home Goods",
        subcategory: "Lighting",
        stockQuantity: 28,
        reorderPoint: 15,
        cost: 22,
        price: 39.99,
        isPerishable: false
      },
      {
        name: "HDMI Cable",
        description: "6ft HDMI cable, 4K compatible",
        category: "Electronics",
        subcategory: "Accessories",
        stockQuantity: 3,
        reorderPoint: 30,
        cost: 5,
        price: 12.99,
        isPerishable: false
      },
      {
        name: "Cotton T-Shirt",
        description: "100% cotton t-shirt, medium size",
        category: "Clothing",
        subcategory: "Tops",
        stockQuantity: 28,
        reorderPoint: 20,
        cost: 8,
        price: 19.99,
        isPerishable: false
      }
    ];

    products.forEach(p => this.createProduct(p));

    // Add some inventory activities
    this.createInventory({
      productId: 2, // Wireless Earbuds
      quantity: 50,
      activityType: "received",
      notes: "Stock received from supplier"
    });

    this.createInventory({
      productId: 3, // Desk Lamp
      quantity: -5,
      activityType: "adjustment",
      notes: "Inventory adjustment after stock count"
    });

    this.createInventory({
      productId: 4, // HDMI Cable
      quantity: 3,
      activityType: "received",
      notes: "Low stock alert"
    });

    // Add default settings
    const defaultSettings = [
      { key: "company_name", value: "InventoryPro Inc.", category: "general" },
      { key: "currency", value: "USD", category: "general" },
      { key: "date_format", value: "MM/DD/YYYY", category: "general" },
      { key: "time_zone", value: "UTC-08:00", category: "general" },
      { key: "language", value: "English", category: "general" },
      { key: "dark_mode", value: "false", category: "general" },
      
      { key: "lead_time_days", value: "5", category: "inventory" },
      { key: "safety_stock_percentage", value: "15", category: "inventory" },
      { key: "order_cost", value: "20", category: "inventory" },
      { key: "holding_cost_percentage", value: "25", category: "inventory" },
      { key: "auto_calculate_reorder", value: "true", category: "inventory" },
      
      { key: "auto_sync", value: "true", category: "sync" },
      { key: "real_time_updates", value: "false", category: "sync" },
      { key: "sync_frequency", value: "daily", category: "sync" },
      { key: "sync_time", value: "01:00", category: "sync" },
      { key: "sync_product_info", value: "true", category: "sync" },
      { key: "sync_inventory", value: "true", category: "sync" },
      { key: "sync_pricing", value: "true", category: "sync" },
      { key: "sync_customer_data", value: "false", category: "sync" },
      { key: "sync_failure_action", value: "retry_1h", category: "sync" },
      { key: "sync_notification_emails", value: "admin@example.com", category: "sync" },
      
      { key: "backup_frequency", value: "daily", category: "backup" },
      { key: "backup_retention", value: "30", category: "backup" },
      { key: "cloud_backup", value: "true", category: "backup" }
    ];

    defaultSettings.forEach(s => this.updateSetting(s.key, s.value, s.category));

    // Add sync history
    this.createSyncHistory({
      syncType: "scheduled",
      recordsProcessed: 284,
      durationSeconds: 105,
      status: "completed",
      errorMessage: ""
    });

    this.createSyncHistory({
      syncType: "scheduled",
      recordsProcessed: 284,
      durationSeconds: 112,
      status: "completed",
      errorMessage: ""
    });

    this.createSyncHistory({
      syncType: "manual",
      recordsProcessed: 6,
      durationSeconds: 15,
      status: "completed",
      errorMessage: ""
    });

    this.createSyncHistory({
      syncType: "scheduled",
      recordsProcessed: 0,
      durationSeconds: 45,
      status: "failed",
      errorMessage: "Database connection timeout"
    });

    // Add purchase orders
    this.createPurchaseOrder({
      poNumber: "PO-2023-0125",
      supplier: "ElectroSupply Inc.",
      itemCount: 5,
      totalValue: 4250.00,
      expectedDelivery: new Date("2023-07-15"),
      status: "in_transit"
    });

    this.createPurchaseOrder({
      poNumber: "PO-2023-0124",
      supplier: "Home Goods Depot",
      itemCount: 3,
      totalValue: 1875.50,
      expectedDelivery: new Date("2023-07-18"),
      status: "processing"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { 
      ...insertUser, 
      id,
      lastLogin: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getUsers(): Promise<UserWithoutPassword[]> {
    return Array.from(this.users.values()).map(({password, ...user}) => user);
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const existingUser = this.users.get(id);
    if (!existingUser) return undefined;

    const updatedUser = {
      ...existingUser,
      ...userData
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // Product operations
  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productCurrentId++;
    const now = new Date();
    const product: Product = {
      ...insertProduct,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, productData: Partial<InsertProduct>): Promise<Product | undefined> {
    const existingProduct = this.products.get(id);
    if (!existingProduct) return undefined;

    const updatedProduct = {
      ...existingProduct,
      ...productData,
      updatedAt: new Date()
    };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    return this.products.delete(id);
  }

  // Inventory operations
  async getInventory(id: number): Promise<Inventory | undefined> {
    return this.inventoryItems.get(id);
  }

  async getInventoryByProductId(productId: number): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values())
      .filter(item => item.productId === productId);
  }

  async getAllInventory(): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values());
  }

  async createInventory(insertInventory: InsertInventory): Promise<Inventory> {
    const id = this.inventoryCurrentId++;
    const inventory: Inventory = {
      ...insertInventory,
      id,
      lastUpdated: new Date()
    };
    this.inventoryItems.set(id, inventory);
    return inventory;
  }

  async getInventoryActivities(limit: number = 10): Promise<Inventory[]> {
    return Array.from(this.inventoryItems.values())
      .sort((a, b) => 
        new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime()
      )
      .slice(0, limit);
  }

  // Settings operations
  async getSetting(key: string): Promise<Setting | undefined> {
    return this.settingsMap.get(key);
  }

  async getSettingsByCategory(category: string): Promise<Setting[]> {
    return Array.from(this.settingsMap.values())
      .filter(setting => setting.category === category);
  }

  async getAllSettings(): Promise<Setting[]> {
    return Array.from(this.settingsMap.values());
  }

  async updateSetting(key: string, value: string, category?: string): Promise<Setting | undefined> {
    const existingSetting = this.settingsMap.get(key);
    
    if (existingSetting) {
      const updatedSetting = {
        ...existingSetting,
        value,
        updatedAt: new Date()
      };
      this.settingsMap.set(key, updatedSetting);
      return updatedSetting;
    } else if (category) {
      // Create new setting if it doesn't exist and category is provided
      const id = this.settingsCurrentId++;
      const newSetting: Setting = {
        id,
        key,
        value,
        category,
        updatedAt: new Date()
      };
      this.settingsMap.set(key, newSetting);
      return newSetting;
    }
    
    return undefined;
  }

  // Sync history operations
  async getSyncHistory(limit: number = 10): Promise<SyncHistory[]> {
    return Array.from(this.syncHistoryItems.values())
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )
      .slice(0, limit);
  }

  async createSyncHistory(insertSyncHistory: InsertSyncHistory): Promise<SyncHistory> {
    const id = this.syncHistoryCurrentId++;
    const syncHistory: SyncHistory = {
      ...insertSyncHistory,
      id,
      createdAt: new Date()
    };
    this.syncHistoryItems.set(id, syncHistory);
    return syncHistory;
  }

  // Purchase orders
  async getPurchaseOrders(): Promise<PurchaseOrder[]> {
    return Array.from(this.purchaseOrdersMap.values())
      .sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  async createPurchaseOrder(insertPurchaseOrder: InsertPurchaseOrder): Promise<PurchaseOrder> {
    const id = this.purchaseOrderCurrentId++;
    const purchaseOrder: PurchaseOrder = {
      ...insertPurchaseOrder,
      id,
      createdAt: new Date()
    };
    this.purchaseOrdersMap.set(id, purchaseOrder);
    return purchaseOrder;
  }

  async updatePurchaseOrder(id: number, data: Partial<InsertPurchaseOrder>): Promise<PurchaseOrder | undefined> {
    const existingOrder = this.purchaseOrdersMap.get(id);
    if (!existingOrder) return undefined;

    const updatedOrder = {
      ...existingOrder,
      ...data
    };
    this.purchaseOrdersMap.set(id, updatedOrder);
    return updatedOrder;
  }
}

export const storage = new MemStorage();

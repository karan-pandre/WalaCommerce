import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertProductSchema, insertInventorySchema, insertPurchaseOrderSchema } from "@shared/schema";
import { generateDemandForecast, detectInventoryAnomalies, recommendSyncFrequency, calculateReplenishmentRecommendation, generateReplenishmentSchedule, batchCategorizeProducts } from "./services/analytics";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix for all routes
  const apiPrefix = "/api";

  // Health check endpoint
  app.get(`${apiPrefix}/health`, (req, res) => {
    res.json({ status: "ok", timestamp: new Date() });
  });

  // ==== User Management ====
  
  // Get all users
  app.get(`${apiPrefix}/users`, async (req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Get user by ID
  app.get(`${apiPrefix}/users/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Create new user
  app.post(`${apiPrefix}/users`, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Update user
  app.patch(`${apiPrefix}/users/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const userData = insertUserSchema.partial().parse(req.body);
      const updatedUser = await storage.updateUser(id, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return the password
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Delete user
  app.delete(`${apiPrefix}/users/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const success = await storage.deleteUser(id);
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // ==== Products ====
  
  // Get all products
  app.get(`${apiPrefix}/products`, async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get product by ID
  app.get(`${apiPrefix}/products/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }

      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Create new product
  app.post(`${apiPrefix}/products`, async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  // Update product
  app.patch(`${apiPrefix}/products/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }

      const productData = insertProductSchema.partial().parse(req.body);
      const updatedProduct = await storage.updateProduct(id, productData);
      
      if (!updatedProduct) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(updatedProduct);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid product data", errors: error.errors });
      }
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  // Delete product
  app.delete(`${apiPrefix}/products/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }

      const success = await storage.deleteProduct(id);
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // ==== Inventory ====
  
  // Get recent inventory activities
  app.get(`${apiPrefix}/inventory/activities`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activities = await storage.getInventoryActivities(limit);
      
      // Get product details to include with activities
      const productsMap = new Map();
      const products = await storage.getProducts();
      products.forEach(product => productsMap.set(product.id, product));
      
      const activitiesWithProductDetails = activities.map(activity => {
        const product = productsMap.get(activity.productId);
        return {
          ...activity,
          productName: product ? product.name : "Unknown Product",
          productCategory: product ? product.category : null
        };
      });
      
      res.json(activitiesWithProductDetails);
    } catch (error) {
      console.error("Error fetching inventory activities:", error);
      res.status(500).json({ message: "Failed to fetch inventory activities" });
    }
  });

  // Create inventory activity
  app.post(`${apiPrefix}/inventory`, async (req, res) => {
    try {
      const inventoryData = insertInventorySchema.parse(req.body);
      
      // Verify product exists
      const product = await storage.getProduct(inventoryData.productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Create the inventory record
      const inventory = await storage.createInventory(inventoryData);
      
      // Update product stock quantity
      await storage.updateProduct(product.id, {
        stockQuantity: product.stockQuantity + inventoryData.quantity
      });
      
      res.status(201).json(inventory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid inventory data", errors: error.errors });
      }
      console.error("Error creating inventory record:", error);
      res.status(500).json({ message: "Failed to create inventory record" });
    }
  });

  // ==== Settings ====
  
  // Get all settings
  app.get(`${apiPrefix}/settings`, async (req, res) => {
    try {
      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // Get settings by category
  app.get(`${apiPrefix}/settings/:category`, async (req, res) => {
    try {
      const category = req.params.category;
      const settings = await storage.getSettingsByCategory(category);
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings by category:", error);
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  // Update setting
  app.patch(`${apiPrefix}/settings/:key`, async (req, res) => {
    try {
      const key = req.params.key;
      const schema = z.object({ value: z.string() });
      const { value } = schema.parse(req.body);
      
      const updatedSetting = await storage.updateSetting(key, value);
      if (!updatedSetting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.json(updatedSetting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid setting data", errors: error.errors });
      }
      console.error("Error updating setting:", error);
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // ==== Sync History ====
  
  // Get sync history
  app.get(`${apiPrefix}/sync/history`, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const history = await storage.getSyncHistory(limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching sync history:", error);
      res.status(500).json({ message: "Failed to fetch sync history" });
    }
  });

  // Create sync history entry
  app.post(`${apiPrefix}/sync/history`, async (req, res) => {
    try {
      const schema = z.object({
        syncType: z.string(),
        recordsProcessed: z.number(),
        durationSeconds: z.number(),
        status: z.string(),
        errorMessage: z.string().optional()
      });
      
      const syncData = schema.parse(req.body);
      const syncHistory = await storage.createSyncHistory(syncData);
      res.status(201).json(syncHistory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sync history data", errors: error.errors });
      }
      console.error("Error creating sync history:", error);
      res.status(500).json({ message: "Failed to create sync history" });
    }
  });

  // ==== Purchase Orders ====
  
  // Get purchase orders
  app.get(`${apiPrefix}/purchase-orders`, async (req, res) => {
    try {
      const orders = await storage.getPurchaseOrders();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching purchase orders:", error);
      res.status(500).json({ message: "Failed to fetch purchase orders" });
    }
  });

  // Create purchase order
  app.post(`${apiPrefix}/purchase-orders`, async (req, res) => {
    try {
      const orderData = insertPurchaseOrderSchema.parse(req.body);
      const order = await storage.createPurchaseOrder(orderData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid purchase order data", errors: error.errors });
      }
      console.error("Error creating purchase order:", error);
      res.status(500).json({ message: "Failed to create purchase order" });
    }
  });

  // Update purchase order
  app.patch(`${apiPrefix}/purchase-orders/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }

      const orderData = insertPurchaseOrderSchema.partial().parse(req.body);
      const updatedOrder = await storage.updatePurchaseOrder(id, orderData);
      
      if (!updatedOrder) {
        return res.status(404).json({ message: "Purchase order not found" });
      }
      
      res.json(updatedOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid purchase order data", errors: error.errors });
      }
      console.error("Error updating purchase order:", error);
      res.status(500).json({ message: "Failed to update purchase order" });
    }
  });

  // ==== Analytics ====
  
  // Generate demand forecast
  app.get(`${apiPrefix}/analytics/forecast/:productId`, async (req, res) => {
    try {
      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Get historical data for the product if available
      const inventoryHistory = await storage.getInventoryByProductId(productId);
      
      // Generate demand data from inventory history
      const historicalDemand = inventoryHistory
        .filter(item => item.quantity < 0) // Only count decreases as demand
        .map(item => Math.abs(item.quantity));
      
      const forecast = await generateDemandForecast(product, historicalDemand);
      res.json(forecast);
    } catch (error) {
      console.error("Error generating forecast:", error);
      res.status(500).json({ message: "Failed to generate forecast" });
    }
  });

  // Generate batch forecasts
  app.get(`${apiPrefix}/analytics/forecasts`, async (req, res) => {
    try {
      const categoryParam = req.query.category as string | undefined;
      
      const products = await storage.getProducts();
      const filteredProducts = categoryParam 
        ? products.filter(p => p.category === categoryParam)
        : products;
      
      // Generate forecasts for products (limited to avoid overload)
      const productLimit = Math.min(10, filteredProducts.length);
      const selectedProducts = filteredProducts.slice(0, productLimit);
      
      const forecasts = await Promise.all(
        selectedProducts.map(async (product) => {
          const forecast = await generateDemandForecast(product, []);
          return {
            productId: product.id,
            productName: product.name,
            category: product.category,
            currentStock: product.stockQuantity,
            forecast
          };
        })
      );
      
      res.json(forecasts);
    } catch (error) {
      console.error("Error generating forecasts:", error);
      res.status(500).json({ message: "Failed to generate forecasts" });
    }
  });

  // Detect inventory anomalies
  app.get(`${apiPrefix}/analytics/anomalies`, async (req, res) => {
    try {
      const inventoryHistory = await storage.getAllInventory();
      const anomalies = detectInventoryAnomalies(inventoryHistory);
      
      // Get product details for the anomalies
      const productsMap = new Map();
      const products = await storage.getProducts();
      products.forEach(product => productsMap.set(product.id, product));
      
      const anomaliesWithProductDetails = await Promise.all(
        anomalies.map(async anomaly => {
          const product = productsMap.get(anomaly.productId);
          return {
            ...anomaly,
            productName: product ? product.name : "Unknown Product",
            category: product ? product.category : null
          };
        })
      );
      
      res.json(anomaliesWithProductDetails);
    } catch (error) {
      console.error("Error detecting anomalies:", error);
      res.status(500).json({ message: "Failed to detect anomalies" });
    }
  });

  // Get sync frequency recommendations
  app.get(`${apiPrefix}/analytics/sync-frequency/:productId`, async (req, res) => {
    try {
      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      const inventoryHistory = await storage.getInventoryByProductId(productId);
      const recommendation = recommendSyncFrequency(product, inventoryHistory);
      
      res.json({
        productId,
        productName: product.name,
        ...recommendation
      });
    } catch (error) {
      console.error("Error generating sync frequency recommendation:", error);
      res.status(500).json({ message: "Failed to generate recommendation" });
    }
  });

  // Get replenishment recommendations
  app.get(`${apiPrefix}/analytics/replenishment/:productId`, async (req, res) => {
    try {
      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }
      
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Get inventory settings
      const leadTimeSetting = await storage.getSetting('lead_time_days');
      const orderCostSetting = await storage.getSetting('order_cost');
      const holdingCostSetting = await storage.getSetting('holding_cost_percentage');
      
      const leadTimeDays = leadTimeSetting ? parseInt(leadTimeSetting.value) : 5;
      const orderCost = orderCostSetting ? parseFloat(orderCostSetting.value) : 20;
      const holdingCostPercent = holdingCostSetting ? parseFloat(holdingCostSetting.value) / 100 : 0.25;
      
      const recommendation = await calculateReplenishmentRecommendation(
        product, [], leadTimeDays, orderCost, holdingCostPercent
      );
      
      res.json({
        ...recommendation,
        productName: product.name,
        category: product.category
      });
    } catch (error) {
      console.error("Error generating replenishment recommendation:", error);
      res.status(500).json({ message: "Failed to generate recommendation" });
    }
  });

  // Get replenishment schedule
  app.get(`${apiPrefix}/analytics/replenishment-schedule`, async (req, res) => {
    try {
      const products = await storage.getProducts();
      const inventoryHistory = await storage.getAllInventory();
      
      const recommendations = await generateReplenishmentSchedule(products, inventoryHistory);
      
      // Add product names to the recommendations
      const productsMap = new Map();
      products.forEach(product => productsMap.set(product.id, product));
      
      const recommendationsWithNames = recommendations.map(rec => {
        const product = productsMap.get(rec.productId);
        return {
          ...rec,
          productName: product ? product.name : "Unknown Product",
          category: product ? product.category : null
        };
      });
      
      res.json(recommendationsWithNames);
    } catch (error) {
      console.error("Error generating replenishment schedule:", error);
      res.status(500).json({ message: "Failed to generate schedule" });
    }
  });

  // Get product categorization suggestions
  app.get(`${apiPrefix}/analytics/categorize`, async (req, res) => {
    try {
      const products = await storage.getProducts();
      const suggestions = batchCategorizeProducts(products);
      res.json(suggestions);
    } catch (error) {
      console.error("Error generating categorization suggestions:", error);
      res.status(500).json({ message: "Failed to generate suggestions" });
    }
  });

  // ==== Dashboard Stats ====
  
  app.get(`${apiPrefix}/dashboard/stats`, async (req, res) => {
    try {
      const products = await storage.getProducts();
      const inventoryHistory = await storage.getAllInventory();
      const purchaseOrders = await storage.getPurchaseOrders();
      
      // Calculate stats
      const totalProducts = products.length;
      
      // Calculate low stock items
      const lowStockItems = products.filter(
        product => product.stockQuantity <= product.reorderPoint
      ).length;
      
      // Calculate pending orders
      const pendingOrders = purchaseOrders.filter(
        order => order.status === 'processing' || order.status === 'in_transit'
      ).length;
      
      // Calculate inventory value
      const inventoryValue = products.reduce(
        (total, product) => total + (product.cost * product.stockQuantity),
        0
      );
      
      // Calculate category breakdown
      const categories = new Map<string, number>();
      products.forEach(product => {
        const category = product.category || 'Uncategorized';
        const currentCount = categories.get(category) || 0;
        categories.set(category, currentCount + 1);
      });
      
      const categoryBreakdown = Array.from(categories.entries()).map(([category, count]) => ({
        category,
        count,
        percentage: Math.round((count / totalProducts) * 100)
      }));
      
      res.json({
        totalProducts,
        lowStockItems,
        pendingOrders,
        inventoryValue,
        categoryBreakdown
      });
    } catch (error) {
      console.error("Error generating dashboard stats:", error);
      res.status(500).json({ message: "Failed to generate stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

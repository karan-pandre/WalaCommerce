# InventoryPro

A comprehensive inventory management system with analytics, system settings, synchronization, user management, and auto-replenishment features.

## Features

- **Dashboard**: Overview of inventory status, recent activities, and key metrics
- **Analytics**: Demand forecasting and anomaly detection
- **Replenishment**: Automated purchase order recommendations based on stock levels and demand forecasts
- **Sync**: Configuration for data synchronization with external systems
- **Users**: User management with role-based permissions
- **Settings**: System configuration and preferences

## Tech Stack

- **Frontend**: React, TailwindCSS, shadcn/ui components, React Query
- **Backend**: Express.js
- **State Management**: React Query, Context API
- **Storage**: In-memory database with persistence capabilities

## Setup and Installation

1. Clone the repository
   ```
   git clone https://github.com/karan-pandre/inventorypro.git
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Start the development server
   ```
   npm run dev
   ```

4. Navigate to the application in your browser at `http://localhost:5000`

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Screenshots

*Coming soon*
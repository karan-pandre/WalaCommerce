import { pgTable, text, serial, integer, boolean, timestamp, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Original users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  role: text("role").default("viewer"),
  lastLogin: timestamp("last_login"),
  isActive: boolean("is_active").default(true),
});

// Products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  subcategory: text("subcategory"),
  stockQuantity: integer("stock_quantity").default(0),
  reorderPoint: integer("reorder_point").default(10),
  cost: real("cost").default(0),
  price: real("price").default(0),
  isPerishable: boolean("is_perishable").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Inventory history table
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow(),
  activityType: text("activity_type"), // "received", "adjustment", "sold"
  notes: text("notes"),
});

// System settings table
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
  category: text("category"), // "general", "inventory", "sync", "backup"
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Sync history table
export const syncHistory = pgTable("sync_history", {
  id: serial("id").primaryKey(),
  syncType: text("sync_type"), // "scheduled", "manual"
  recordsProcessed: integer("records_processed"),
  durationSeconds: integer("duration_seconds"),
  status: text("status"), // "completed", "failed"
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Purchase orders table
export const purchaseOrders = pgTable("purchase_orders", {
  id: serial("id").primaryKey(),
  poNumber: text("po_number").notNull(),
  supplier: text("supplier"),
  itemCount: integer("item_count"),
  totalValue: real("total_value"),
  createdAt: timestamp("created_at").defaultNow(),
  expectedDelivery: timestamp("expected_delivery"),
  status: text("status"), // "processing", "in_transit", "delivered", "cancelled"
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  role: true,
  isActive: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  lastUpdated: true,
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

export const insertSyncHistorySchema = createInsertSchema(syncHistory).omit({
  id: true,
  createdAt: true,
});

export const insertPurchaseOrderSchema = createInsertSchema(purchaseOrders).omit({
  id: true,
  createdAt: true,
});

// Select types
export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Inventory = typeof inventory.$inferSelect;
export type Setting = typeof settings.$inferSelect;
export type SyncHistory = typeof syncHistory.$inferSelect;
export type PurchaseOrder = typeof purchaseOrders.$inferSelect;

// Insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertInventory = z.infer<typeof insertInventorySchema>;
export type InsertSetting = z.infer<typeof insertSettingsSchema>;
export type InsertSyncHistory = z.infer<typeof insertSyncHistorySchema>;
export type InsertPurchaseOrder = z.infer<typeof insertPurchaseOrderSchema>;

// Custom types for frontend
export type ReplenishmentRecommendation = {
  productId: number;
  currentStock: number;
  recommendedQuantity: number;
  urgency: 'high' | 'medium' | 'low';
  expectedDemand: number;
  leadTimeDays: number;
  daysUntilStockout: number;
  costSavings: number;
};

export type DemandForecast = {
  forecast: number[];
  confidence: number;
  method: string;
};

export type InventoryAnomaly = {
  productId: number;
  anomalyType: 'sudden_change' | 'data_gap' | 'unexpected_zero';
  severity: 'high' | 'medium' | 'low';
  details: string;
};

export type SyncFrequencyRecommendation = {
  frequency: string;
  reasoning: string;
};

export type UserWithoutPassword = Omit<User, 'password'>;
